#!/usr/bin/env python3

from typing import Dict, Any
from argparse import Namespace

from platform_engine.tasks.order_details.get_platform_configs import get_platform_configs
from platform_engine.platforms.base_platform_client import PlatformConfig
from platform_engine.core.metadata_manager import MetadataManager
from platform_engine.core.batch_data_writer import BatchDataWriter
from platform_engine.core.storage_manager import StorageManagerFactory
from platform_engine.tasks.order_details.utils import setup_logger
from platform_engine.tasks.order_details.config import GetOrderDetailsConfig
from platform_engine.tasks.order_details.run_lazada import run_lazada
from platform_engine.tasks.order_details.run_shopee import run_shopee
from platform_engine.shared_utils.directory import resolve_source_and_output_paths
from platform_engine.shared_utils.platform_api_name import get_order_list_api_name, get_order_details_api_name


def run_extraction(params: Dict[str, Any]):
    """
    The Core Execution Logic.
    Can be called by CLI (via main) or by a Fabric Notebook.
    """
    args = Namespace(**params)

    # 1. Setup Resources
    logger = setup_logger(args.platform, getattr(args, 'log_file'))
    storage = StorageManagerFactory.create(
        logger, getattr(args, 'storage_type'))

    # 2. Context Preparation - Resolve source and output paths
    (source_orders_dir, full_output_dir,
     platform, created_after, created_before) = resolve_source_and_output_paths(
        storage,
        args,
        get_order_list_api_name(args.platform),
        get_order_details_api_name(args.platform),
        logger
    )

    # Validate platform matches
    if args.platform != platform:
        raise ValueError(
            f"Platform mismatch: --platform={args.platform} but source has platform={platform}"
        )

    # 3. Configuration & Client Initialization
    common_order = GetOrderDetailsConfig(
        platform=platform,
        source_orders_dir=source_orders_dir,
        output_dir=full_output_dir,
        batch_size_mb=getattr(args, 'batch_size_mb'),
        storage_type=getattr(args, 'storage_type')
    )

    common_client = PlatformConfig(
        request_delay=getattr(args, 'request_delay'),
        max_retries=getattr(args, 'max_retries'),
        retry_backoff_factor=getattr(args, 'retry_backoff_factor'),
        timeout_seconds=getattr(args, 'timeout_seconds'),
    )

    platform_configs = get_platform_configs(
        args=args,
        common_client=common_client,
        common_order=common_order
    )

    client = platform_configs.client(
        config=platform_configs.client_config,
        logger=logger
    )

    order_details_config = platform_configs.order_details_config

    # 4. Data Extraction Execution
    metadata = MetadataManager(storage, logger, full_output_dir)
    metadata.register_config(order_details_config)
    writer = BatchDataWriter(
        storage,
        metadata,
        logger,
        order_details_config.batch_size_mb
    )

    try:
        metadata.update_status("running")

        if args.platform == 'shopee':
            run_shopee(client, writer, order_details_config)
        else:
            run_lazada(client, writer, order_details_config)

        writer.finalize()
        metadata.update_status("completed")

        return {
            "status": "success",
            "platform": args.platform,
            "output_path": full_output_dir
        }

    except Exception as e:
        metadata.update_status("failed")
        logger.error(
            f"Execution failed for {args.platform}: {e}", exc_info=True)
        raise e
