from functools import partial
from typing import List
from platform_engine.core.batch_data_writer import BatchDataWriter
from platform_engine.platforms.shopee_client import ShopeeClient
from platform_engine.tasks.order_details.config import ShopeeOrderDetailsConfig
from platform_engine.shared_utils.metadata import get_ids_from_source
from platform_engine.shared_utils.check_platform_response_error import check_shopee_response_error


def validate_shopee_order_details_response(
    response: dict,
    requested_ids: List[str],
):
    check_shopee_response_error(response)

    request_id = response.get('request_id')
    order_list = response.get('response', {}).get('order_list', [])
    returned_ids = {str(o.get('order_sn')) for o in order_list if o}
    missing = [rid for rid in requested_ids if str(rid) not in returned_ids]

    if missing:
        raise ValueError(
            f"Incomplete data. Missing IDs: {missing}. Request ID: {request_id}")


def run_shopee(client: ShopeeClient, writer: BatchDataWriter, config: ShopeeOrderDetailsConfig):
    """
    Shopee order details fetching implementation.

    Loads order_sn list from source, batches requests, and writes records.
    """
    # Load order_sns from source order_list data
    order_sns = get_ids_from_source(
        storage_manager=writer.storage_manager,
        source_dir=config.source_orders_dir,
        id_field_name="order_sn",
        logger=client.logger
    )

    if not order_sns:
        client.logger.warning("No order_sns found in source data. Exiting.")
        return

    # Process in batches
    total_orders = len(order_sns)
    client.logger.info(
        f"Processing {total_orders} order_sns in batches of {config.shp_batch_size}"
    )

    for i in range(0, total_orders, config.shp_batch_size):
        batch_ids = order_sns[i:i + config.shp_batch_size]
        progress_pct = (i / total_orders) * 100

        client.logger.info(
            f"Progress: {i}/{total_orders} ({progress_pct:.1f}%) - Fetching batch of {len(batch_ids)} orders"
        )

        # Create validator with batch-specific context using partial
        validator = partial(
            validate_shopee_order_details_response,
            requested_ids=batch_ids,
        )

        # API call with validator
        response = client.request(
            method="GET",
            path="/api/v2/order/get_order_detail",
            params={
                'order_sn_list': ','.join(str(sn) for sn in batch_ids),
                'response_optional_fields': 'buyer_user_id,cancel_by,cancel_reason,item_list,total_amount'
            },
            validator=validator
        )

        # Extract and write records
        order_list = response.get('response', {}).get('order_list', [])
        for order in order_list:
            writer.add_record(order)

        client.logger.info(
            f"Fetched {len(order_list)} order details for batch"
        )

    client.logger.info(
        f"Completed fetching order details for {total_orders} orders"
    )
