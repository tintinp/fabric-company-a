from dataclasses import dataclass
from typing import Optional

from platform_engine.shared_utils.script_setup import get_default_params

_defaults = get_default_params()


@dataclass
class GetOrderDetailsConfig():
    platform: str
    output_dir: str
    source_orders_dir: str  # Path to order_list data directory
    batch_size_mb: float = _defaults['batch_size_mb']
    storage_type: Optional[str] = _defaults['storage_type']


@dataclass
class ShopeeOrderDetailsConfig(GetOrderDetailsConfig):
    shp_batch_size: int = _defaults['shp_batch_size']


@dataclass
class LazadaOrderDetailsConfig(GetOrderDetailsConfig):
    lzd_batch_size: int = _defaults['lzd_batch_size']
