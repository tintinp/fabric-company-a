from functools import partial
from typing import List
from urllib import response
from platform_engine.core.batch_data_writer import BatchDataWriter
from platform_engine.platforms.lazada_client import LazadaClient
from platform_engine.tasks.order_details.config import LazadaOrderDetailsConfig
from platform_engine.shared_utils.metadata import extract_ids_from_batches, get_ids_from_source, validate_source_metadata
from platform_engine.shared_utils.check_platform_response_error import check_lazada_response_error


def validate_lazada_order_items_response(
    response: dict,
    requested_ids: List[int],
):
    """
    Validates Lazada's order items API response.
    Checks for API errors, empty responses, and missing IDs.
    """
    # Check Lazada API error code
    check_lazada_response_error(response)

    # Extract order items
    order_items = response.get('data', [])
    request_id = response.get('request_id')

    # Check for empty response
    if not order_items:
        raise ValueError(
            f"Lazada returned empty order items unexpectedly. Request ID: {request_id}"
        )

    # Validate all requested IDs are present in response
    returned_ids = {str(o.get('order_id')) for o in order_items if o}
    requested_ids_str = [str(rid) for rid in requested_ids]
    missing_ids = [rid for rid in requested_ids_str if rid not in returned_ids]

    if missing_ids:
        raise ValueError(
            f"Incomplete data. Missing order_ids: {missing_ids}. Request ID: {request_id}"
        )


def run_lazada(client: LazadaClient, writer: BatchDataWriter, config: LazadaOrderDetailsConfig):
    """
    Lazada order items fetching implementation.

    Loads order_id list from source, batches requests, and writes records.
    Note: Lazada calls it 'order_items' but we normalize to 'order_details'.
    """
    # Load order_ids from source order_list data
    order_ids = get_ids_from_source(
        storage_manager=writer.storage_manager,
        source_dir=config.source_orders_dir,
        id_field_name="order_id",
        logger=client.logger
    )
    validate_source_metadata(storage_manager=writer.storage_manager,
                             directory=config.source_orders_dir, logger=client.logger)

    order_ids = extract_ids_from_batches(
        storage_manager=writer.storage_manager, directory=config.source_orders_dir, id_field="order_id", logger=client.logger)
    if not order_ids:
        client.logger.warning("No order_ids found in source data. Exiting.")
        return

    # Process in batches
    total_orders = len(order_ids)
    client.logger.info(
        f"Processing {total_orders} order_ids in batches of {config.lzd_batch_size}"
    )

    for i in range(0, total_orders, config.lzd_batch_size):
        batch_ids = order_ids[i:i + config.lzd_batch_size]
        progress_pct = (i / total_orders) * 100

        client.logger.info(
            f"Progress: {i}/{total_orders} ({progress_pct:.1f}%) - Fetching batch of {len(batch_ids)} orders"
        )

        # Create validator with batch-specific context using partial
        validator = partial(
            validate_lazada_order_items_response,
            requested_ids=batch_ids,
        )

        # API call with validator
        # Note: Lazada SDK handles JSON stringification of list parameters
        response = client.request(
            method="GET",
            path="/orders/items/get",
            params={
                'order_ids': batch_ids  # Will be JSON stringified by SDK
            },
            validator=validator
        )

        # Extract and write records
        order_items = response.get('data', [])
        for order in order_items:
            writer.add_record(order)

        client.logger.info(
            f"Fetched {len(order_items)} order items for batch"
        )

    client.logger.info(
        f"Completed fetching order items for {total_orders} orders"
    )
