#!/usr/bin/env python3
"""
Order Details Utilities
Argument parsing, validation, and path resolution for order details fetching
"""

import logging
import argparse
from platform_engine.shared_utils.script_setup import (
    setup_logger as _setup_logger,
    add_common_arguments,
    validate_source_metadata_args,
    get_default_params
)


def setup_logger(platform: str, log_file: str = None) -> logging.Logger:
    """Setup logging configuration"""
    if not log_file:
        log_file = f'{platform}_order_details_fetcher.log'
    return _setup_logger(platform, 'OrderDetailsFetcher', log_file)


def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description='Fetch order details from e-commerce platforms',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    # Add common arguments
    add_common_arguments(parser)

    defaults = get_default_params()

    # Order details specific arguments
    parser.add_argument(
        '--source-metadata-path',
        default=None,
        help='Path to source metadata.json file from order list (e.g., data/lazada/order_list/2025-09-01_2025-09-30_1234567890/metadata.json). If not provided, will auto-discover using --date'
    )
    parser.add_argument(
        '--date',
        default=defaults['date'],
        help='Date for auto-discovery of order_list data. Formats: "YYYY-MM" (monthly), "YYYY-MM-DD" (daily), or "YYYY-MM-DD-YYYY-MM-DD" (custom). Mutually exclusive with --source-metadata-path'
    )
    parser.add_argument(
        '--shp-batch-size',
        type=int,
        default=defaults['shp_batch_size'],
        help='Number of orders to fetch details for per request (max 50)'
    )
    parser.add_argument(
        '--lzd-batch-size',
        type=int,
        default=defaults['lzd_batch_size'],
        help='Number of orders to fetch details for per request (max 50)'
    )

    return parser.parse_args()


def validate_arguments(args: argparse.Namespace) -> None:
    """
    Validate argument combinations

    Args:
        args: Parsed arguments

    Raises:
        ValueError: If invalid argument combination
    """
    validate_source_metadata_args(args)
