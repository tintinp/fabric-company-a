#!/usr/bin/env python3

from typing import Dict, Any
from argparse import Namespace

# Existing imports from your project structure
from platform_engine.tasks.order_list.get_platform_configs import get_platform_configs
from platform_engine.platforms.base_platform_client import PlatformConfig
from platform_engine.shared_utils.logger import setup_logger
from platform_engine.core.metadata_manager import MetadataManager
from platform_engine.core.batch_data_writer import BatchDataWriter
from platform_engine.core.storage_manager import StorageManagerFactory
from platform_engine.tasks.order_list.utils import calculate_date_range, resolve_output_path
from platform_engine.tasks.order_list.run_lazada import run_lazada
from platform_engine.tasks.order_list.run_shopee import run_shopee
from platform_engine.tasks.order_list.config import GetOrderListConfig
from platform_engine.shared_utils.platform_api_name import get_order_list_api_name


def run_extraction(params: Dict[str, Any]):
    """
    The Core Execution Logic. 
    Can be called by CLI (via main) or by a Fabric Notebook.
    """
    # Convert dictionary to a Namespace to maintain compatibility
    # with existing utility functions
    args = Namespace(**params)

    # 1. Setup Resources
    logger = setup_logger(args.platform, getattr(args, 'log_file'))
    storage = StorageManagerFactory.create(
        logger, getattr(args, 'storage_type'))

    # 2. Context Preparation
    # Calculate dates using the utility logic
    created_after, created_before = calculate_date_range(
        frequency=args.frequency,
        month=getattr(args, 'month'),
        date=getattr(args, 'date'),
        created_after=getattr(args, 'created_after'),
        created_before=getattr(args, 'created_before'),
        timezone_name=getattr(args, 'timezone', 'Asia/Bangkok')
    )

    api_name = get_order_list_api_name(args.platform)
    full_output_dir = resolve_output_path(storage, args, api_name)

    # 3. Configuration & Client Initialization
    common_order = GetOrderListConfig(
        frequency=args.frequency,
        platform=args.platform,
        created_after=created_after,
        created_before=created_before,
        output_dir=full_output_dir,
        batch_size_mb=getattr(args, 'batch_size_mb'),
        ignore_empty_list=getattr(args, 'ignore_empty_list')
    )

    common_client = PlatformConfig(
        request_delay=getattr(args, 'request_delay'),
        max_retries=getattr(args, 'max_retries'),
        retry_backoff_factor=getattr(args, 'retry_backoff_factor'),
        timeout_seconds=getattr(args, 'timeout_seconds'),
    )

    # Use the platform factory
    platform_configs = get_platform_configs(
        args=args,
        common_client=common_client,
        common_order=common_order
    )

    client = platform_configs.client(
        config=platform_configs.client_config,
        logger=logger
    )

    order_list_config = platform_configs.order_config

    # 4. Data Extraction Execution
    metadata = MetadataManager(storage, logger, full_output_dir)
    metadata.register_config(order_list_config)
    writer = BatchDataWriter(storage, metadata, logger,
                             order_list_config.batch_size_mb)

    try:
        metadata.update_status("running")

        if args.platform == 'shopee':
            run_shopee(client, writer, order_list_config)
        else:
            run_lazada(client, writer, order_list_config)

        writer.finalize()
        metadata.update_status("completed")

        return {
            "status": "success",
            "platform": args.platform,
            "output_path": full_output_dir
        }

    except Exception as e:
        metadata.update_status("failed")
        logger.error(
            f"Execution failed for {args.platform}: {e}", exc_info=True)
        raise e
