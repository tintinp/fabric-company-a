#!/usr/bin/env python3
"""
Order List Fetcher
Fetches order list from e-commerce platforms (Shopee, Lazada)
"""


import logging
import argparse
import os
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from zoneinfo import ZoneInfo

from platform_engine.shared_utils.script_setup import (
    setup_logger as _setup_logger,
    add_common_arguments,
    get_default_params
)


def setup_logger(platform: str, log_file: str = None) -> logging.Logger:
    """Setup logging configuration"""
    if not log_file:
        log_file = f'{platform}_order_list_fetcher.log'
    return _setup_logger(platform, 'OrderListFetcher', log_file)


def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description='Fetch order list from e-commerce platforms',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    # Add common arguments
    add_common_arguments(parser)

    defaults = get_default_params()

    # Frequency selection
    parser.add_argument(
        '--frequency',
        required=True,
        choices=['monthly', 'daily', 'custom'],
        help='Data fetch frequency type'
    )

    # Frequency-specific arguments
    parser.add_argument(
        '--month',
        default=defaults['month'],
        help='Month for monthly frequency (format: YYYY-MM, e.g., 2025-04)'
    )
    parser.add_argument(
        '--date',
        default=defaults['date'],
        help='Date for daily frequency (format: YYYY-MM-DD, e.g., 2025-04-01)'
    )
    parser.add_argument(
        '--timezone',
        default=defaults['timezone'],
        help='Timezone name (IANA format, e.g., Asia/Bangkok, Asia/Singapore, UTC)'
    )
    parser.add_argument(
        '--created-after',
        default=defaults['created_after'],
        help='Fetch orders created after this date (required for custom frequency, ISO format with timezone, e.g., 2025-09-01T00:00:00+07:00)'
    )
    parser.add_argument(
        '--created-before',
        default=defaults['created_before'],
        help='Fetch orders created before this date (required for custom frequency, ISO format with timezone, e.g., 2025-10-15T23:59:59+07:00)'
    )

    # Platform-specific arguments
    parser.add_argument(
        '--shp-page-size',
        type=int,
        default=defaults['shp_page_size'],
        help='Number of orders to fetch per request (max 100, Shopee only)'
    )
    parser.add_argument(
        '--shp-query-range-days',
        type=int,
        # 11 is chosen because last chunk would be 23-01 of the next month. this should return at least an order. ideally we dont want 0 order to be returned because we dont know if it is API issue or it is realy no order.
        default=defaults['shp_query_range_days'],
        help='Number of days per query range chunk for order list (Shopee only, max 15 days)'
    )
    parser.add_argument(
        '--lzd-orders-limit',
        type=int,
        default=defaults['lzd_orders_limit'],
        help='Number of orders to fetch per request (max 100, Lazada only)'
    )
    parser.add_argument(
        '--ignore-empty-list',
        type=lambda x: str(x).lower() in ('true', '1', 'yes', 'y'),
        default=defaults['ignore_empty_list'],
        help='Ignore empty order list responses without raising exceptions (Shopee only)'
    )

    return parser.parse_args()


def calculate_date_range(frequency: str, month: str = None, date: str = None,
                         created_after: str = None, created_before: str = None,
                         timezone_name: str = 'Asia/Bangkok') -> tuple[str, str]:
    """
    Calculate date range based on frequency type with proper timezone handling

    Args:
        frequency: 'monthly', 'daily', or 'custom'
        month: Month string for monthly frequency (format: YYYY-MM)
        date: Date string for daily frequency (format: YYYY-MM-DD)
        created_after: Start date for custom frequency (ISO format with timezone)
        created_before: End date for custom frequency (ISO format with timezone)
        timezone_name: IANA timezone name (e.g., 'Asia/Bangkok', 'UTC')

    Returns:
        Tuple of (created_after, created_before) in ISO format with timezone

    Examples:
        Monthly: calculate_date_range('monthly', month='2025-04', timezone_name='Asia/Bangkok')
                 Returns: ('2025-04-01T00:00:00+07:00', '2025-05-01T00:00:00+07:00')

        Daily: calculate_date_range('daily', date='2025-04-01', timezone_name='Asia/Bangkok')
               Returns: ('2025-04-01T00:00:00+07:00', '2025-04-02T00:00:00+07:00')
    """
    try:
        tz = ZoneInfo(timezone_name)
    except Exception as e:
        raise ValueError(f"Invalid timezone name '{timezone_name}': {e}")

    if frequency == 'monthly':
        if not month:
            raise ValueError("--month is required for monthly frequency")

        # Parse month (e.g., '2025-04')
        try:
            year, month_num = map(int, month.split('-'))
        except ValueError:
            raise ValueError(
                f"Invalid month format '{month}'. Expected YYYY-MM (e.g., 2025-04)")

        # Create timezone-aware datetime for first day of the month at 00:00:00
        start_dt = datetime(year, month_num, 1, 0, 0, 0, tzinfo=tz)

        # End: first day of next month at 00:00:00 (using relativedelta for clean month handling)
        end_dt = start_dt + relativedelta(months=1)

    elif frequency == 'daily':
        if not date:
            raise ValueError("--date is required for daily frequency")

        # Parse date (e.g., '2025-04-01')
        try:
            year, month_num, day = map(int, date.split('-'))
        except ValueError:
            raise ValueError(
                f"Invalid date format '{date}'. Expected YYYY-MM-DD (e.g., 2025-04-01)")

        # Create timezone-aware datetime for the day at 00:00:00
        start_dt = datetime(year, month_num, day, 0, 0, 0, tzinfo=tz)

        # End: next day at 00:00:00
        end_dt = start_dt + timedelta(days=1)

    elif frequency == 'custom':
        if not created_after or not created_before:
            raise ValueError(
                "--created-after and --created-before are required for custom frequency")

        # For custom, dates are already provided in ISO format with timezone
        # Just validate they can be parsed
        try:
            datetime.fromisoformat(created_after)
            datetime.fromisoformat(created_before)
        except ValueError as e:
            raise ValueError(f"Invalid date format for custom frequency: {e}")

        return created_after, created_before

    else:
        raise ValueError(f"Invalid frequency: {frequency}")

    # Format as ISO 8601 with timezone using isoformat()
    return start_dt.isoformat(), end_dt.isoformat()


def validate_arguments(args: argparse.Namespace) -> None:
    """
    Validate argument combinations based on frequency

    Args:
        args: Parsed arguments

    Raises:
        ValueError: If invalid argument combination
    """
    if args.frequency == 'monthly' and not args.month:
        raise ValueError("--month is required when using --frequency monthly")

    if args.frequency == 'daily' and not args.date:
        raise ValueError("--date is required when using --frequency daily")

    if args.frequency == 'custom':
        if not args.created_after or not args.created_before:
            raise ValueError(
                "--created-after and --created-before are required when using --frequency custom")


def resolve_output_path(storage, args, platform_query_type: str) -> str:
    """
    Handles the directory versioning logic.
    Returns the final absolute path for the current execution.
    """
    from platform_engine.shared_utils.metadata import get_next_version

    # 1. Format the date part of the directory
    if args.frequency == 'monthly':
        directory_date = args.month.replace('-', '_')
    elif args.frequency == 'daily':
        directory_date = args.date.replace('-', '_')
    else:
        from datetime import datetime
        start_dt = datetime.fromisoformat(args.created_after)
        end_dt = datetime.fromisoformat(args.created_before)
        directory_date = f"{start_dt.strftime('%Y_%m_%d')}-{end_dt.strftime('%Y_%m_%d')}"

    # 2. Build base path
    base_dir = os.path.join(
        args.output_dir or os.path.join(os.getcwd(), 'data'),
        args.frequency,
        args.platform,
        platform_query_type,
        directory_date
    )

    # 3. Resolve versioning
    version = get_next_version(storage, base_dir, logging.getLogger())
    return os.path.join(base_dir, str(version))
