from platform_engine.core.batch_data_writer import BatchDataWriter
from platform_engine.platforms.lazada_client import LazadaClient
from platform_engine.tasks.order_list.config import LazadaOrderListConfig
from platform_engine.shared_utils.check_platform_response_error import check_lazada_response_error


def validate_lazada_response(response: dict, ignore_empty: bool = False):
    """
    Validates Lazada's SDK response.
    Catches the 'Ghost Data' bug where countTotal > 0 but orders is empty.
    """
    check_lazada_response_error(response)
    data = response.get('data', {})
    orders = data.get('orders', [])
    count_total = data.get('countTotal', 0)

    if not orders and count_total > 0 and not ignore_empty:
        raise ValueError(
            f"Lazada Ghost Data: countTotal is {count_total} but orders is empty.")


def run_lazada(client: LazadaClient, writer: BatchDataWriter, config: LazadaOrderListConfig):
    offset = 0
    total_count_reached = False

    while not total_count_reached:
        # 1. Global Timeout Check (Moved inside client.request in our new architecture,
        # but good to keep here for visibility)

        # 2. Execute Request with our Injected Validator
        # Note: 'validate_lazada_response' handles the "Ghost Data" bug
        response = client.request(
            method="GET",
            path="/orders/get",
            params={
                "created_after": config.created_after,
                "created_before": config.created_before,
                "offset": offset,
                "limit": config.lzd_orders_limit
            },
            validator=validate_lazada_response
        )

        # 3. Extract Data
        data = response.get('data', {})
        orders = data.get('orders', [])
        count_total = data.get('countTotal', 0)

        # 4. Processing
        if orders:
            for order in orders:
                writer.add_record(order)

            client.logger.info(
                f"Fetched {len(orders)} orders (offset: {offset}, total API count: {count_total})"
            )
        else:
            # SAFETY: If we get 0 orders but we haven't hit count_total,
            # we stop to avoid infinite loops, but log it as a warning.
            if offset < count_total:
                client.logger.warning(
                    f"Stop triggered: No orders returned at offset {offset} "
                    f"despite countTotal being {count_total}."
                )
            break

        # 5. Update Offset
        # Use actual count received to be safer than config.limit
        offset += len(orders)

        # 6. Exit Condition
        # If we've processed as many or more than the API said existed, we are done.
        if offset >= count_total or len(orders) < config.lzd_orders_limit:
            client.logger.info(
                f"Lazada fetch complete. Total processed: {offset}")
            total_count_reached = True

    # 7. Final Flush
    writer.finalize()
