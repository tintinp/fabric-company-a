from dataclasses import dataclass
from typing import Optional

from platform_engine.shared_utils.script_setup import get_default_params

_defaults = get_default_params()


@dataclass
class GetOrderListConfig():
    frequency: str
    platform: str
    output_dir: str
    created_after: str
    created_before: str
    batch_size_mb: float = _defaults['batch_size_mb']
    ignore_empty_list: bool = _defaults['ignore_empty_list']
    storage_type: Optional[str] = _defaults['storage_type']


@dataclass
class ShopeeOrderListConfig(GetOrderListConfig):
    shp_page_size: int = _defaults['shp_page_size']
    # 11 is chosen because last chunk would be 23-01 of the next month. this should return at least an order. ideally we dont want 0 order to be returned because we dont know if it is API issue or it is realy no order.
    shp_query_range_days: int = _defaults['shp_query_range_days']


@dataclass
class LazadaOrderListConfig(GetOrderListConfig):
    lzd_orders_limit: int = _defaults['lzd_orders_limit']
