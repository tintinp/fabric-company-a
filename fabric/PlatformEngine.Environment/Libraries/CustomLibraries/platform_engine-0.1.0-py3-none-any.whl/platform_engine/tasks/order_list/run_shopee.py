from datetime import datetime
from platform_engine.core.batch_data_writer import BatchDataWriter
from platform_engine.platforms.shopee_client import ShopeeClient
from platform_engine.tasks.order_list.config import ShopeeOrderListConfig
from platform_engine.shared_utils.check_platform_response_error import check_shopee_response_error
from platform_engine.shared_utils.date import split_date_range_into_chunks


def validate_shopee_response(response: dict, ignore_empty: bool = False):
    """
    Validates Shopee's specific response structure.
    Shopee often returns 200 OK with an error field in the JSON.
    """
    check_shopee_response_error(response)

    # Data check
    resp_data = response.get('response', {})
    orders = resp_data.get('order_list', [])

    if not orders and not ignore_empty:
        # If we expect data but get none, we might want to retry
        # to ensure it wasn't a transient "empty response" bug.
        raise ValueError("Shopee returned an empty order list unexpectedly.")


def run_shopee(client: ShopeeClient, writer: BatchDataWriter, config: ShopeeOrderListConfig):

    # 1. Chunk the time range
    chunks = split_date_range_into_chunks(
        config.created_after,
        config.created_before,
        config.shp_query_range_days
    )

    for idx, (start, end) in enumerate(chunks):
        cursor = ""
        client.logger.info(
            f"Processing chunk {idx + 1}/{len(chunks)}: "
            f"{datetime.fromtimestamp(start)} to {datetime.fromtimestamp(end)}"
        )
        while True:
            response = client.request(
                "GET", "/api/v2/order/get_order_list",
                params={
                    "time_range_field": "create_time",
                    "time_from": start,
                    "time_to": end,
                    "page_size": config.shp_page_size,
                    "cursor": cursor
                },
                validator=validate_shopee_response
            )

            data = response.get('response', {})
            orders = data.get('order_list', [])
            more = data.get('more', False)

            for order in orders:
                writer.add_record(order)

            client.logger.info(
                f"Fetched {len(orders)} order items "
                f"(cursor: {cursor}, more: {more})"
            )

            if not more or not data.get('next_cursor'):
                break
            cursor = data.get('next_cursor')
