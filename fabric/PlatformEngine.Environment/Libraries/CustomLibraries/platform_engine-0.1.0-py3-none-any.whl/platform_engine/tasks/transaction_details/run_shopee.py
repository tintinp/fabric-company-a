from functools import partial
from typing import List
from platform_engine.core.batch_data_writer import BatchDataWriter
from platform_engine.platforms.shopee_client import ShopeeClient
from platform_engine.tasks.transaction_details.config import ShopeeEscrowDetailsConfig
from platform_engine.shared_utils.metadata import get_ids_from_source
from platform_engine.shared_utils.check_platform_response_error import check_shopee_response_error


def validate_shopee_escrow_details_response(
    response: dict,
    requested_ids: List[str],
):
    """
    Validates that the Shopee API returned escrow details for all requested IDs.
    """
    check_shopee_response_error(response)

    request_id = response.get('request_id')
    # Shopee escrow response structure: response -> escrow_list/order_list
    # Adjusting based on your source logic: records = response.get('response', [])
    records = response.get('response', [])

    # Extract order_sn from the nested escrow_detail object
    returned_ids = {
        str(r.get('escrow_detail', {}).get('order_sn'))
        for r in records if r and r.get('escrow_detail')
    }

    missing = [rid for rid in requested_ids if str(rid) not in returned_ids]

    if missing:
        raise ValueError(
            f"Incomplete escrow data. Missing IDs: {missing}. Request ID: {request_id}"
        )


def run_shopee_escrow(client: ShopeeClient, writer: BatchDataWriter, config: ShopeeEscrowDetailsConfig):
    """
    Shopee escrow details fetching implementation.

    Loads order_sns from source order list, batches requests to the escrow endpoint,
    and writes results to the data store.
    """
    # Load order_sns from source data
    order_sns = get_ids_from_source(
        storage_manager=writer.storage_manager,
        source_dir=config.source_orders_dir,
        id_field_name="order_sn",
        logger=client.logger
    )

    if not order_sns:
        client.logger.warning(
            "No order_sns found in source data to fetch escrow details. Exiting.")
        return

    total_orders = len(order_sns)
    batch_size = config.escrow_details_batch_size

    client.logger.info(
        f"Processing {total_orders} order escrow details in batches of {batch_size}"
    )

    for i in range(0, total_orders, batch_size):
        batch_ids = order_sns[i:i + batch_size]
        progress_pct = (i / total_orders) * 100

        client.logger.info(
            f"Progress: {i}/{total_orders} ({progress_pct:.1f}%) - Fetching escrow batch"
        )

        # Create validator with current batch context
        validator = partial(
            validate_shopee_escrow_details_response,
            requested_ids=batch_ids,
        )

        # API call using the client's request wrapper
        # The endpoint for escrow batch is typically POST
        response = client.request(
            method="POST",
            path="/api/v2/payment/get_escrow_detail_batch",
            body={
                'order_sn_list': batch_ids
            },
            validator=validator
        )

        # Extract records and write
        records = response.get('response', [])
        for record in records:
            writer.add_record(record)

        client.logger.info(
            f"Successfully wrote {len(records)} escrow records for batch"
        )

    client.logger.info(
        f"Completed fetching escrow details for {total_orders} orders"
    )
