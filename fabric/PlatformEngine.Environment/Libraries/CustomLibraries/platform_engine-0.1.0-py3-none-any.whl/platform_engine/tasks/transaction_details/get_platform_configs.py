from dataclasses import dataclass, asdict
from typing import Any, Union
from platform_engine.tasks.transaction_details.config import (
    GetTransactionDetailsConfig,
    LazadaTransactionDetailsConfig,
    ShopeeEscrowDetailsConfig
)
from platform_engine.platforms.base_platform_client import PlatformConfig
from platform_engine.platforms.lazada_client import LazadaClient, LazadaClientConfig, build_lazada_client_config
from platform_engine.platforms.shopee_client import ShopeeClient, ShopeeClientConfig, build_shopee_client_config


@dataclass
class PlatformConfigs:
    client: Union[ShopeeClient, LazadaClient]
    transaction_config: Union[ShopeeEscrowDetailsConfig,
                              LazadaTransactionDetailsConfig]
    client_config: Union[ShopeeClientConfig, LazadaClientConfig]


def get_platform_configs(
    args: Any,
    common_order: GetTransactionDetailsConfig,
    common_client: PlatformConfig
) -> PlatformConfigs:
    """
    Factory that returns fully instantiated, type-checked config and client.
    """
    base_order_dict = asdict(common_order)

    if args.platform == 'shopee':
        transaction_config = ShopeeEscrowDetailsConfig(
            **base_order_dict,
            escrow_details_batch_size=args.shp_escrow_details_batch_size
        )
        client_config = build_shopee_client_config(common_client)
        client = ShopeeClient

    elif args.platform == 'lazada':
        transaction_config = LazadaTransactionDetailsConfig(
            **base_order_dict,
            transactions_limit=args.lzd_transactions_limit,
            date_buffer_days=args.lzd_date_buffer_days,
        )
        client_config = build_lazada_client_config(common_client)
        client = LazadaClient

    else:
        raise ValueError(f"Unknown platform: {args.platform}")

    return PlatformConfigs(
        client=client,
        transaction_config=transaction_config,
        client_config=client_config
    )
