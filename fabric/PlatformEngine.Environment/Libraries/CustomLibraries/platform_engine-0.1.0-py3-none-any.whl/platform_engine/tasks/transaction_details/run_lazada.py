from typing import Set
from platform_engine.core.batch_data_writer import BatchDataWriter
from platform_engine.platforms.lazada_client import LazadaClient
from platform_engine.tasks.transaction_details.config import LazadaTransactionDetailsConfig
from platform_engine.shared_utils.metadata import (
    extract_ids_and_fields_from_batches,
    validate_source_metadata
)
from platform_engine.shared_utils.check_platform_response_error import check_lazada_response_error


def run_lazada_transaction_details(
    client: LazadaClient,
    writer: BatchDataWriter,
    config: LazadaTransactionDetailsConfig
):
    """
    Lazada transaction details fetching implementation.

    Paginates through the finance API and filters records based on source order IDs.
    Validates that confirmed orders have corresponding transaction records.
    """
    # 1. Validate source and load order IDs with statuses for post-run validation
    validate_source_metadata(
        storage_manager=writer.storage_manager,
        directory=config.source_orders_dir,
        logger=client.logger
    )

    order_ids, id_to_fields = extract_ids_and_fields_from_batches(
        storage_manager=writer.storage_manager,
        directory=config.source_orders_dir,
        id_field='order_id',
        additional_fields=['statuses'],
        logger=client.logger
    )

    if not order_ids:
        client.logger.warning("No order_ids found in source data. Exiting.")
        return

    order_ids_set = {int(oid) for oid in order_ids}
    orders_with_transactions: Set[int] = set()
    offset = 0

    # 2. Paginated Fetching Loop
    while True:
        client.logger.info(f"Fetching transactions at offset {offset}...")

        # API call with basic structural validation
        response = client.request(
            method="GET",
            path="/finance/transaction/details/get",
            params={
                'offset': str(offset),
                'limit': str(config.transactions_limit),
                'start_time': config.created_after,
                'end_time': config.created_before
            },
            validator=check_lazada_response_error
        )

        records = response.get('data', [])
        if not records:
            client.logger.info("No more records returned from API.")
            break

        # 3. Process records and track found IDs
        for record in records:
            try:
                # Lazada uses order_no in finance API, which maps to order_id
                oid = int(record.get('order_no'))
                if oid in order_ids_set:
                    orders_with_transactions.add(oid)
                    writer.add_record(record)
            except (ValueError, TypeError):
                continue

        offset += config.transactions_limit

        # Safety break if transactions exceed a reasonable limit or page is empty
        if len(records) < config.transactions_limit:
            break

    # 4. Final Validation: Check for confirmed orders missing transactions
    missing = order_ids_set - orders_with_transactions
    confirmed_missing = [
        oid for oid in missing
        if 'confirmed' in id_to_fields.get(str(oid), {}).get('statuses', [])
    ]

    if confirmed_missing:
        client.logger.error(
            f"Validation Failed: {len(confirmed_missing)} confirmed orders missing transactions."
        )
        raise ValueError(
            f"Missing transaction data for confirmed orders: {confirmed_missing}")

    client.logger.info(
        f"Completed. Fetched transactions for {len(orders_with_transactions)}/{len(order_ids_set)} orders."
    )
