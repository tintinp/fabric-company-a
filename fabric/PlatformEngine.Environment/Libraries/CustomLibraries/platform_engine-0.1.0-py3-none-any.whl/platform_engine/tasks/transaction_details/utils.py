#!/usr/bin/env python3
"""
Transaction/Escrow Details Utilities
Argument parsing, validation, and path resolution for finance data fetching
"""

import logging
import argparse
from platform_engine.shared_utils.script_setup import (
    setup_logger as _setup_logger,
    add_common_arguments,
    validate_source_metadata_args,
    get_default_params
)


def setup_logger(platform: str, log_file: str = None) -> logging.Logger:
    """Setup logging configuration for finance fetcher"""
    if not log_file:
        log_file = f'{platform}_transaction_details_fetcher.log'
    return _setup_logger(platform, 'TransactionDetailsFetcher', log_file)


def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments for finance data extraction"""
    parser = argparse.ArgumentParser(
        description='Fetch transaction (Lazada) or escrow (Shopee) details',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    # Add common arguments
    add_common_arguments(parser)

    defaults = get_default_params()

    # Transaction details specific arguments
    parser.add_argument(
        '--source-metadata-path',
        default=None,
        help='Path to source metadata.json from order list. Mutually exclusive with --date'
    )
    parser.add_argument(
        '--date',
        default=defaults['date'],
        help='Date for auto-discovery of order_list data (YYYY-MM, YYYY-MM-DD)'
    )

    # Platform-specific arguments with prefixes
    # Shopee specific
    parser.add_argument(
        '--shp-escrow-details-batch-size',
        type=int,
        default=defaults['shp_escrow_details_batch_size'],
        help='Number of orders to fetch escrow details for per request (Shopee max 50)'
    )

    # Lazada specific
    parser.add_argument(
        '--lzd-transactions-limit',
        type=int,
        default=defaults['lzd_transactions_limit'],
        help='Page size for transaction API requests (Lazada max 100)'
    )
    parser.add_argument(
        '--lzd-date-buffer-days',
        type=int,
        default=defaults['lzd_date_buffer_days'],
        help='Days to extend end date for finance queries to catch late payments (Lazada only)'
    )

    return parser.parse_args()


def validate_arguments(args: argparse.Namespace) -> None:
    """Validate argument combinations for finance fetching"""
    validate_source_metadata_args(args)
