#!/usr/bin/env python3

from typing import Dict, Any
from argparse import Namespace

from platform_engine.core.batch_data_writer import BatchDataWriter
from platform_engine.core.metadata_manager import MetadataManager
from platform_engine.core.storage_manager import StorageManagerFactory
from platform_engine.tasks.transaction_details.get_platform_configs import get_platform_configs
from platform_engine.platforms.base_platform_client import PlatformConfig
from platform_engine.tasks.transaction_details.config import GetTransactionDetailsConfig
from platform_engine.tasks.transaction_details.utils import (
    parse_arguments,
    validate_arguments,
    setup_logger
)
from platform_engine.tasks.transaction_details.run_shopee import run_shopee_escrow
from platform_engine.tasks.transaction_details.run_lazada import run_lazada_transaction_details
from platform_engine.shared_utils.platform_api_name import get_order_list_api_name, get_transaction_details_api_name
from platform_engine.shared_utils.directory import resolve_source_and_output_paths


def run_extraction(params: Dict[str, Any]):
    """
    The Core Execution Logic.
    Can be called by CLI (via main) or by a Fabric Notebook.
    """
    args = Namespace(**params)

    # 1. Setup Resources
    logger = setup_logger(args.platform, getattr(args, 'log_file'))
    storage = StorageManagerFactory.create(
        logger, getattr(args, 'storage_type'))

    # 2. Path Discovery & Platform Validation
    (source_orders_dir, full_output_dir,
     platform, created_after, created_before) = resolve_source_and_output_paths(
         storage,
         args,
         get_order_list_api_name(args.platform),
         get_transaction_details_api_name(args.platform),
         logger
    )

    if args.platform != platform:
        raise ValueError(
            f"Platform mismatch: --platform={args.platform} vs source={platform}")

    # 3. Configuration & Client Initialization
    common_order = GetTransactionDetailsConfig(
        platform=platform,
        source_orders_dir=source_orders_dir,
        output_dir=full_output_dir,
        batch_size_mb=getattr(args, 'batch_size_mb'),
        storage_type=getattr(args, 'storage_type'),
        created_after=created_after,
        created_before=created_before
    )

    common_client = PlatformConfig(
        request_delay=getattr(args, 'request_delay'),
        max_retries=getattr(args, 'max_retries'),
        retry_backoff_factor=getattr(args, 'retry_backoff_factor'),
        timeout_seconds=getattr(args, 'timeout_seconds'),
    )

    platform_configs = get_platform_configs(
        args=args,
        common_client=common_client,
        common_order=common_order
    )

    client = platform_configs.client(
        config=platform_configs.client_config,
        logger=logger
    )

    transaction_config = platform_configs.transaction_config

    # 4. Data Extraction Execution
    metadata = MetadataManager(storage, logger, full_output_dir)
    metadata.register_config(transaction_config)
    writer = BatchDataWriter(
        storage,
        metadata,
        logger,
        transaction_config.batch_size_mb
    )

    try:
        metadata.update_status("running")
        logger.info(f"Starting finance data extraction for {platform}")

        if platform == 'shopee':
            run_shopee_escrow(client, writer, transaction_config)
        elif platform == 'lazada':
            run_lazada_transaction_details(
                client, writer, transaction_config)
        else:
            raise ValueError(f"Unsupported platform: {platform}")

        writer.finalize()
        metadata.update_status("completed")
        logger.info("Finance data extraction completed successfully.")

        return {
            "status": "success",
            "platform": platform,
            "output_path": full_output_dir
        }

    except Exception as e:
        metadata.update_status("failed")
        logger.error(
            f"Execution failed for {platform}: {e}", exc_info=True)
        raise e
