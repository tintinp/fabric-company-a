from dataclasses import dataclass
from typing import Optional

from platform_engine.shared_utils.script_setup import get_default_params

_defaults = get_default_params()


@dataclass
class GetTransactionDetailsConfig():
    platform: str
    output_dir: str
    source_orders_dir: str  # Path to order_list data directory
    batch_size_mb: float = _defaults['batch_size_mb']
    created_after: str = ""
    created_before: str = ""
    storage_type: Optional[str] = _defaults['storage_type']


@dataclass
class LazadaTransactionDetailsConfig(GetTransactionDetailsConfig):
    transactions_limit: int = _defaults['lzd_transactions_limit']
    date_buffer_days: int = _defaults['lzd_date_buffer_days']


@dataclass
class ShopeeEscrowDetailsConfig(GetTransactionDetailsConfig):
    escrow_details_batch_size: int = _defaults['shp_escrow_details_batch_size']
