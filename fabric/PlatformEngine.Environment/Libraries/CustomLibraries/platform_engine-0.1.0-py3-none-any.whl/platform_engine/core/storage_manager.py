#!/usr/bin/env python3
"""
Unified Storage Manager for Local and OneLake
Handles reading and writing data for both local filesystem and OneLake storage
"""

import os
import json
import logging
from typing import List, Dict, Optional
from abc import ABC, abstractmethod


class BaseStorageManager(ABC):
    """Abstract base class for storage managers (read and write)"""

    def __init__(self, logger: logging.Logger):
        self.logger = logger

    @abstractmethod
    def write_batch(self, filepath: str, records: List[Dict]):
        """Write a batch of records to storage"""
        pass

    @abstractmethod
    def write_file(self, filepath: str, content: str):
        """Write string content to a single file"""
        pass

    @abstractmethod
    def read_file(self, filepath: str) -> str:
        """Read file content from storage"""
        pass

    @abstractmethod
    def file_exists(self, filepath: str) -> bool:
        """Check if file exists"""
        pass

    @abstractmethod
    def list_files(self, directory: str, pattern: str = "*") -> List[str]:
        """List files in directory matching pattern"""
        pass

    @abstractmethod
    def list_directory(self, directory: str) -> List[str]:
        """List all items (files and directories) in directory"""
        pass

    @abstractmethod
    def is_directory(self, filepath: str) -> bool:
        """Check if path is a directory"""
        pass


class LocalStorageManager(BaseStorageManager):
    """Local filesystem storage manager"""

    def write_batch(self, filepath: str, records: List[Dict]):
        """Write batch to local file"""
        # Ensure directory exists
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        # Write JSONL
        with open(filepath, 'w', encoding='utf-8') as f:
            for record in records:
                f.write(json.dumps(record, ensure_ascii=False) + '\n')

        self.logger.info(f"Wrote {len(records)} records to {filepath}")

    def write_file(self, filepath: str, content: str):
        """Write string content to local file"""
        # Ensure directory exists
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        # Write content
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)

        self.logger.info(f"Wrote file to {filepath}")

    def read_file(self, filepath: str) -> str:
        """Read file from local storage"""
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()

    def file_exists(self, filepath: str) -> bool:
        """Check if local file exists"""
        return os.path.exists(filepath)

    def list_files(self, directory: str, pattern: str = "*") -> List[str]:
        """List files in local directory"""
        if not os.path.exists(directory):
            return []

        from glob import glob
        pattern_path = os.path.join(directory, pattern)
        return glob(pattern_path)

    def list_directory(self, directory: str) -> List[str]:
        """List all items in local directory"""
        if not os.path.exists(directory):
            return []

        return os.listdir(directory)

    def is_directory(self, filepath: str) -> bool:
        """Check if path is a directory"""
        return os.path.isdir(filepath)


class OneLakeStorageManager(BaseStorageManager):
    """OneLake storage manager using mssparkutils"""

    def __init__(self, logger: logging.Logger):
        super().__init__(logger)

        try:
            from notebookutils import mssparkutils
            self.fs = mssparkutils.fs
            self.logger.info("OneLake storage initialized successfully")
        except ImportError:
            raise ImportError(
                "notebookutils not available. "
                "OneLake storage can only be used in Microsoft Fabric environment."
            )

    def write_batch(self, filepath: str, records: List[Dict]):
        """Write batch to OneLake"""
        # Convert records to JSONL string
        content = '\n'.join(json.dumps(record, ensure_ascii=False)
                            for record in records)

        # Write to OneLake (overwrites if exists)
        self.fs.put(filepath, content, overwrite=True)

        self.logger.info(f"Wrote {len(records)} records to {filepath}")

    def write_file(self, filepath: str, content: str):
        """Write string content to OneLake"""
        # Write to OneLake (overwrites if exists)
        self.fs.put(filepath, content, overwrite=True)

        self.logger.info(f"Wrote file to {filepath}")

    def read_file(self, filepath: str) -> str:
        """Read file from OneLake"""
        try:
            # mssparkutils.fs.head() reads file content
            return self.fs.head(filepath, 100000000)  # 100MB max read
        except Exception as e:
            self.logger.error(f"Failed to read {filepath}: {e}")
            raise

    def file_exists(self, filepath: str) -> bool:
        """Check if file exists in OneLake"""
        try:
            # Try to get file info
            self.fs.head(filepath, 1)
            return True
        except:
            return False

    def list_files(self, directory: str, pattern: str = "*") -> List[str]:
        """List files in OneLake directory"""
        try:
            files = self.fs.ls(directory)

            # Filter by pattern (simple wildcard matching)
            if pattern != "*":
                import fnmatch
                files = [f for f in files if fnmatch.fnmatch(
                    os.path.basename(f.path), pattern)]

            # Return file paths
            return [f.path for f in files]
        except:
            return []

    def list_directory(self, directory: str) -> List[str]:
        """List all items in OneLake directory"""
        try:
            items = self.fs.ls(directory)
            # Return just the names, not full paths
            return [os.path.basename(item.path) for item in items]
        except:
            return []

    def is_directory(self, filepath: str) -> bool:
        """Check if path is a directory in OneLake"""
        try:
            # Try to list the path - if it's a directory, this will succeed
            self.fs.ls(filepath)
            return True
        except:
            return False


class StorageManagerFactory:
    """Factory for creating appropriate storage manager"""

    @staticmethod
    def create(
        logger: logging.Logger,
        storage_type: Optional[str] = None
    ) -> BaseStorageManager:
        """
        Create storage manager based on storage type or auto-detection

        Args:
            logger: Logger instance
            storage_type: Optional override ('local' or 'onelake')

        Returns:
            Appropriate storage manager instance
        """

        # Explicit override
        if storage_type:
            if storage_type.lower() == 'local':
                logger.info("Using local storage (explicit)")
                return LocalStorageManager(logger)
            elif storage_type.lower() == 'onelake':
                logger.info("Using OneLake storage (explicit)")
                return OneLakeStorageManager(logger)
            else:
                raise ValueError(f"Invalid storage type: {storage_type}")

        # Auto-detection: Try to import notebookutils
        try:
            from notebookutils import mssparkutils
            logger.info("Detected OneLake environment (auto)")
            return OneLakeStorageManager(logger)
        except ImportError:
            logger.info("Using local storage (auto-detected)")
            return LocalStorageManager(logger)
