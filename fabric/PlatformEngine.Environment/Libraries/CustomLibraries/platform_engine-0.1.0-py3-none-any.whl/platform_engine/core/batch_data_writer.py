#!/usr/bin/env python3
"""
Batch Data Writer
Orchestrates the buffering and flushing of records to storage.
"""

import json
import logging
import os
from typing import TypeVar
from typing import List, Dict, Any, Optional
from platform_engine.core.storage_manager import BaseStorageManager
from platform_engine.core.metadata_manager import MetadataManager


StorageManager = TypeVar("T", bound=BaseStorageManager)

class BatchDataWriter:
    """
    Manages the in-memory buffer of records and handles periodic
    flushing to the storage manager as JSONL files.
    """

    def __init__(
        self,
        storage_manager: StorageManager,
        metadata_manager: MetadataManager,
        logger: logging.Logger,
        batch_size_mb: float = 1.0
    ):
        self.storage_manager = storage_manager
        self.metadata_manager = metadata_manager
        self.logger = logger

        # Batching state
        self.batch_size_bytes = int(batch_size_mb * 1024 * 1024)
        self.current_buffer: List[Dict[str, Any]] = []
        self.current_buffer_size = 0
        self.batch_count = 0

    def add_record(self, record: Dict[str, Any]) -> None:
        """
        Adds a single record to the buffer.
        If the buffer exceeds the size threshold, it triggers a flush.
        """
        # Estimate size in bytes (plus 1 for the newline character in JSONL)
        # ensure_ascii=False is used to match your original implementation
        record_json = json.dumps(record, ensure_ascii=False)
        record_size = len(record_json.encode('utf-8')) + 1

        # Check if adding this record would exceed the batch limit
        if self.current_buffer and (self.current_buffer_size + record_size) > self.batch_size_bytes:
            self.flush()

        self.current_buffer.append(record)
        self.current_buffer_size += record_size

    def flush(self) -> Optional[str]:
        """
        Writes the current buffer to a JSONL file and updates metadata.
        Returns the filename if a file was written.
        """
        if not self.current_buffer:
            return None

        self.batch_count += 1
        filename = f"batch_{self.batch_count:04d}.jsonl"

        # Determine the full path relative to the output directory owned by metadata
        output_dir = self.metadata_manager.output_dir
        batch_filepath = os.path.join(output_dir, filename)

        try:
            # We use the metadata's record count to update the stateful manager
            record_count = len(self.current_buffer)

            self.storage_manager.write_batch(
                batch_filepath, self.current_buffer)

            # Update our stateful MetadataManager!
            self.metadata_manager.register_batch(filename, record_count)

            self.logger.info(
                f"Flushed batch {self.batch_count}: {record_count} records "
                f"({self.current_buffer_size / 1024 / 1024:.2f} MB)"
            )

            # Reset buffer
            self.current_buffer = []
            self.current_buffer_size = 0
            return filename

        except Exception as e:
            self.logger.error(f"Failed to flush batch {self.batch_count}: {e}")
            raise

    def finalize(self) -> None:
        """
        To be called at the end of the execution to ensure any 
        remaining records in the buffer are saved.
        """
        if self.current_buffer:
            self.logger.info(
                "Finalizing: Flushing remaining records in buffer.")
            self.flush()
        else:
            self.logger.info("Finalizing: No remaining records to flush.")
