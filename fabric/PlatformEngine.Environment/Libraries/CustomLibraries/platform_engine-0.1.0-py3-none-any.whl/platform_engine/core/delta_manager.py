from typing import Optional
import logging
from pyspark.sql import DataFrame, SparkSession
from delta.tables import DeltaTable
from tenacity import retry, stop_after_attempt, wait_random_exponential

from platform_engine.data_processing.validations import validate_and_align_columns, validate_non_nullable_columns


class DeltaManager:
    def __init__(self, spark: SparkSession, logger: Optional[logging.Logger] = None):
        self.spark = spark
        self.logger = logger or logging.getLogger(__name__)

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_random_exponential(multiplier=1, min=2, max=10),
        retry=lambda e: "ConcurrentAppendException" in str(e),
        reraise=True
    )
    def upsert_to_table(self, df: DataFrame, table_path: str, sk: str):
        """Merges source dataframe into target Delta table using a surrogate key."""
        try:
            # 1. Schema Validation (Externalize these helper functions)
            target_table = DeltaTable.forPath(self.spark, table_path)
            table_schema = target_table.toDF().schema

            df = validate_and_align_columns(df, table_schema, self.logger)
            validate_non_nullable_columns(df, table_schema, self.logger)

            self.logger.info(f"Merging data into {table_path} on {sk}...")

            target_table.alias("target").merge(
                df.alias("source"),
                f"target.{sk} = source.{sk}"
            ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

            # 2. Extract Metrics safely
            history = target_table.history(1).select(
                "operationMetrics").collect()[0][0]
            self.logger.info(
                f"Merge success. Inserted: {history.get('numTargetRowsInserted')}, "
                f"Updated: {history.get('numTargetRowsUpdated')}"
            )
        except Exception as e:
            self.logger.error(f"Failed upsert: {str(e)}")
            raise
