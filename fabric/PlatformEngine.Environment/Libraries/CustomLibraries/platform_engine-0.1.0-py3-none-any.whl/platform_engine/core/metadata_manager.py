#!/usr/bin/env python3
"""
Stateful Metadata Manager
Manages the lifecycle and persistence of execution metadata.
"""

import json
import os
from typing import TypeVar
from datetime import datetime
from typing import Dict, Any, Set
from dataclasses import asdict, is_dataclass
from platform_engine.core.storage_manager import BaseStorageManager
from logging import Logger

StorageManager = TypeVar("T", bound=BaseStorageManager)


class MetadataManager:
    """
    A stateful session manager that owns the metadata for a single execution.
    It automatically redacts sensitive info and persists changes to storage.
    """

    # Fields that should never be written to disk
    SENSITIVE_KEYWORDS: Set[str] = {
        'key', 'token', 'secret', 'password', 'auth', 'credential'
    }

    def __init__(self, storage_manager: StorageManager, logger: Logger, output_dir: str):
        self.storage_manager = storage_manager
        self.logger = logger
        self.output_dir = output_dir
        self.metadata_path = os.path.join(output_dir, 'metadata.json')

        # Initialize the internal state (The In-Memory Copy)
        self._state: Dict[str, Any] = {
            'execution_timestamp': datetime.now().isoformat(),
            'status': 'initialized',
            'total_records': 0,
            'total_batches': 0,
            'output_files': [],
            'config': {},
            'validation': {'api_errors': []}
        }

    def register_config(self, config_obj: Any) -> None:
        """
        Reflectively inspects a config object and stores non-sensitive fields.
        """
        raw_dict = {}
        if is_dataclass(config_obj):
            raw_dict = asdict(config_obj)
        elif hasattr(config_obj, '__dict__'):
            raw_dict = config_obj.__dict__
        else:
            self.logger.warning(
                "Provided config is not a dataclass or object; skipping registration.")
            return

        # Redact sensitive fields
        clean_config = {
            k: v for k, v in raw_dict.items()
            if not any(secret in k.lower() for secret in self.SENSITIVE_KEYWORDS)
        }

        self._state['config'] = clean_config
        self._persist()

    def update_status(self, status: str) -> None:
        """Updates the high-level status (e.g., 'running', 'completed', 'failed')"""
        self._state['status'] = status
        self._state['last_updated'] = datetime.now().isoformat()
        self._persist()

    def register_batch(self, filename: str, record_count: int) -> None:
        """
        Atomic update for batch tracking. 
        Ensures counters and file lists are always in sync.
        """
        self._state['total_records'] += record_count
        self._state['total_batches'] += 1
        self._state['output_files'].append(filename)
        self._state['last_updated'] = datetime.now().isoformat()
        self._persist()

    def log_api_error(self, error_msg: str) -> None:
        """Logs a non-fatal API error to the metadata for auditing"""
        self._state['validation']['api_errors'].append({
            'timestamp': datetime.now().isoformat(),
            'message': error_msg
        })
        self._persist()

    def _persist(self) -> None:
        """Internal method to synchronize the in-memory state with storage."""
        try:
            content = json.dumps(self._state, indent=2)
            self.storage_manager.write_file(self.metadata_path, content)
        except Exception as e:
            # We log but don't crash the whole process if metadata write fails
            self.logger.error(
                f"Failed to persist metadata to {self.metadata_path}: {e}")

    def get_state(self) -> Dict[str, Any]:
        """Returns a copy of the current in-memory state."""
        return self._state.copy()
