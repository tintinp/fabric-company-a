import pycountry
from pyspark.sql import DataFrame, Window, Column, SparkSession
from pyspark.sql.functions import (
    col, row_number, substring, broadcast,
    when, coalesce, lit
)
from pyspark.sql.types import StructType, StructField, StringType
from typing import Callable


def validate_and_prep_campaign_dim(df_dim: DataFrame) -> DataFrame:
    """
    Ensures the campaign table has the required columns 
    and returns only what is needed for the join.
    """
    required = ["date_sk", "campaign_sk"]
    missing = [c for c in required if c not in df_dim.columns]

    if missing:
        raise ValueError(
            f"Campaign dimension is missing required columns: {missing}")

    return df_dim.select("date_sk", "campaign_sk")


def join_campaign(df_fact: DataFrame, df_dim: DataFrame) -> DataFrame:
    """
    Joins Fact with Campaign. 
    Drops 'date_sk' immediately after join to keep schema clean.
    """
    # 1. Prep the dimension (Select only needed columns)
    dim_subset = validate_and_prep_campaign_dim(df_dim)

    # 2. Perform Join
    # Condition: Date match AND Campaign ID match
    condition = [
        df_fact["create_local_date_sk"] == dim_subset["date_sk"],
    ]

    return (
        df_fact.join(broadcast(dim_subset), condition, "left")
        .drop("date_sk")  # Requirement: Drop the join key from the right side
    )


def get_unique_geography(df_geo_raw: DataFrame) -> DataFrame:
    """
    Grain: One row per District + Postal Code.
    """
    # We order by sk to make the 'first' selection deterministic for testing
    win = Window.partitionBy(
        "district_th", "postal_code").orderBy("th_geography_sk")

    return (
        df_geo_raw
        .withColumn("_rn", row_number().over(win))
        .filter(col("_rn") == 1)
        .select("th_geography_sk", "district_th", "postal_code")
    )


def join_geography(df_fact: DataFrame, df_geo_raw: DataFrame) -> DataFrame:
    """
    Performs exact match with a 2-digit postal prefix fallback.
    """
    # 1. Prep Dimension
    geo_dim = get_unique_geography(df_geo_raw).cache()

    # 2. Primary Join (Exact)
    df_joined = df_fact.join(
        broadcast(geo_dim),
        (df_fact["district"] == geo_dim["district_th"]) &
        (df_fact["postal_code"] == geo_dim["postal_code"]),
        "left"
    ).select(df_fact["*"], geo_dim["th_geography_sk"])

    # 3. Fallback Logic for Unmatched
    # Split into matched and unmatched to avoid expensive self-joins
    matched = df_joined.filter(col("th_geography_sk").isNotNull())
    unmatched = df_joined.filter(
        col("th_geography_sk").isNull()).drop("th_geography_sk")

    if unmatched.count() > 0:
        # Create a prefix mapping (e.g., '10' -> first found sk in Bangkok, but it does not guarantee district correctness)
        prefix_win = Window.partitionBy("prefix").orderBy("th_geography_sk")
        prefix_map = (
            geo_dim.withColumn("prefix", substring(col("postal_code"), 1, 2))
            .withColumn("_rn", row_number().over(prefix_win))
            .filter(col("_rn") == 1)
            .select(col("prefix").alias("_map_prefix"), col("th_geography_sk"))
        )

        fixed_unmatched = unmatched.withColumn("_fact_prefix", substring(col("postal_code"), 1, 2)) \
            .join(broadcast(prefix_map), col("_fact_prefix") == col("_map_prefix"), "left") \
            .drop("_fact_prefix", "_map_prefix")

        return matched.unionByName(fixed_unmatched)

    return matched


def translate_lazada_status(raw_status_col: str) -> Column:
    status_col = col(raw_status_col)
    awaiting = ["pending", "packed", "repacked",
                "ready_to_ship_pending", "ready_to_ship"]
    canceled = ["canceled", "shipped_back", "shipped_back_success", "shipped_back_failed",
                "returned", "failed_delivery", "lost_by_3pl", "damaged_by_3pl"]

    return (
        when(status_col == "unpaid", "UNPAID")
        .when(status_col.isin(awaiting), "AWAITING_SHIPMENT")
        .when(status_col == "shipped", "IN_TRANSIT")
        .when(status_col == "delivered", "DELIVERED")
        .when(status_col == "confirmed", "COMPLETE")
        .when(status_col.isin(canceled), "CANCELED")
        .otherwise(None)
    )


def translate_shopee_status(raw_status_col: str) -> Column:
    status_col = col(raw_status_col)
    awaiting = ["READY_TO_SHIP", "PROCESSED"]
    in_transit = ["SHIPPED", "RETRY_SHIP"]
    canceled = ["IN_CANCEL", "CANCELLED", "TO_RETURN"]

    return (
        when(status_col == "UNPAID", "UNPAID")
        .when(status_col.isin(awaiting), "AWAITING_SHIPMENT")
        .when(status_col.isin(in_transit), "IN_TRANSIT")
        .when(status_col == "TO_CONFIRM_RECEIVE", "DELIVERED")
        .when(status_col == "COMPLETED", "COMPLETE")
        .when(status_col.isin(canceled), "CANCELED")
        .otherwise(None)
    )


def join_order_status(
    df: DataFrame,
    dim_df: DataFrame,
    raw_status_name: str,
    translate_fn: Callable[[str], Column]
) -> DataFrame:
    """
    Pure logic: Translates status and joins with the dimension table.
    """
    # 1. Create the standard code column
    temp_code_col = "_standard_status_code"

    return (
        df.withColumn(temp_code_col, translate_fn(raw_status_name))
        .join(
            broadcast(dim_df.select("order_status_code", "order_status_sk")),
            col(temp_code_col) == col("order_status_code"),
            "left"
        )
        # Drop temporary join keys but KEEP the original raw_status_name for auditing
        .drop("order_status_code", temp_code_col)
    )


def join_product(
    df_fact: DataFrame,
    df_dim_product: DataFrame
) -> DataFrame:
    """
    Joins fact with product dimension using a prioritized match:
    1. Try matching variant_id_seller -> sku_seller
    2. Try matching product_id_seller -> sku_seller

    Empty strings are treated as NULLs to prevent incorrect matches.
    """
    # 1. Prep Dimension
    product_lookup = df_dim_product.select(
        col("sku_seller").alias("_dim_sku"),
        "product_sk"
    )

    # 2. Prep Fact: Create a 'Clean' Lookup Key
    # We prioritize variant_id because it's usually the more specific SKU.
    # We explicitly check for empty strings ("") which are common in CSV/JSON raw data.
    df_fact_prepped = df_fact.withColumn(
        "_match_key",
        when((col("variant_id_seller").isNotNull()) & (col("variant_id_seller") != ""),
             col("variant_id_seller"))
        .otherwise(
            when((col("product_id_seller").isNotNull()) & (col("product_id_seller") != ""),
                 col("product_id_seller"))
            .otherwise(lit(None))
        )
    )

    # 3. Perform Join
    return (
        df_fact_prepped.join(
            broadcast(product_lookup),
            col("_match_key") == col("_dim_sku"),
            "left"
        )
        # 4. Fallback for the String Hash SK
        .withColumn("product_sk", coalesce(col("product_sk"), lit("UNKNOWN")))
        .drop("_match_key", "_dim_sku")
    )


def get_country_name(spark: SparkSession, df: DataFrame) -> DataFrame:
    """
    Standardizes country names using ISO alpha-2 codes via pycountry.
    Uses a broadcast join for optimal performance.
    """
    # 1. Generate lookup data locally
    country_data = [(c.alpha_2, c.name) for c in pycountry.countries]

    lookup_schema = StructType([
        StructField("_lookup_code", StringType(), True),
        StructField("country", StringType(), True)
    ])

    # 2. Create the Lookup DF
    country_lookup_df = spark.createDataFrame(
        country_data, schema=lookup_schema)

    # 3. Join
    # We use a specific alias for lookup_code to avoid ambiguity during the join
    return (
        df.join(
            broadcast(country_lookup_df),
            col("country_code") == col("_lookup_code"),
            "left"
        )
        .drop("_lookup_code", "country_code")
    )
