from functools import reduce
from pyspark.sql import functions as F
import operator
from logging import Logger, getLogger
from pyspark.sql import DataFrame
from pyspark.sql.functions import count, col, lit, array, when, sum as spark_sum
from pyspark.sql.types import StructType, NumericType
from functools import reduce as py_reduce

from platform_engine.data_processing.utils import smart_display

default_logger = getLogger(__name__)


def check_duplicates(df: DataFrame, key_columns: list[str], df_name: str = "DataFrame", logger: Logger = default_logger):
    """
    Checks for duplicates. Raises ValueError if found.
    """
    if isinstance(key_columns, str):
        key_columns = [key_columns]

    # Group by key columns and filter for duplicates
    duplicates_df = (
        df.groupBy(key_columns)
        .agg(count("*").alias("row_count"))
        .filter(col("row_count") > 1)
    )

    # We take(1) instead of count() for speed.
    # If there is at least one row, we have a duplicate.
    duplicate_sample = duplicates_df.limit(1).collect()

    if duplicate_sample:
        # If we reach here, there's a problem.
        # Only now do we perform a count() to show the scale of the error.
        total_duplicates = duplicates_df.count()
        error_msg = f"🚨 {total_duplicates} duplicate(s) found in {df_name} by {key_columns}!"
        logger.error(error_msg)
        smart_display(duplicates_df.orderBy(col("row_count").desc()))
        raise ValueError(error_msg)

    logger.info(f"✅ Success: {df_name} uniqueness validated on {key_columns}.")
    return True


def check_row_count_match(df1: DataFrame, df2: DataFrame, df1_name: str = "Source", df2_name: str = "Target", logger: Logger = default_logger):
    """
    Ensures that no rows were lost or accidentally exploded during a join.
    """
    count1 = df1.count()
    count2 = df2.count()

    if count1 != count2:
        diff = abs(count1 - count2)
        error_msg = f"🚨 Mismatch! {df1_name}: {count1:,} vs {df2_name}: {count2:,} (Diff: {diff:,})"
        logger.error(error_msg)
        raise ValueError(error_msg)

    logger.info(f"✅ Success: Row counts match ({count1:,}).")
    return True


def validate_and_align_columns(df: DataFrame, expected_schema: StructType, logger: Logger = default_logger) -> DataFrame:
    """
    Validates schema, auto-fills missing nullable columns, and aligns numeric types.
    Strictly forbids incompatible type changes (e.g., String to Int).
    """
    logger.info("Validating and aligning schema...")
    actual_fields = {field.name: field.dataType for field in df.schema.fields}
    type_mismatches = []
    added_columns = []
    output_df = df

    for field in expected_schema.fields:
        col_name = field.name
        expected_type = field.dataType
        is_nullable = field.nullable

        # Case 1: Column is Missing
        if col_name not in actual_fields:
            if is_nullable:
                added_columns.append(
                    f"  • {col_name}: MISSING (Added as NULL {expected_type.simpleString()})")
                output_df = output_df.withColumn(
                    col_name, lit(None).cast(expected_type))
            else:
                type_mismatches.append(
                    f"  • {col_name}: MISSING (Cannot add, column is NOT NULL)")

        # Case 2: Column exists but type differs
        else:
            actual_type = actual_fields[col_name]
            if actual_type != expected_type:
                # 2a. Check for Numeric Compatibility (e.g., Int vs BigInt)
                if isinstance(actual_type, NumericType) and isinstance(expected_type, NumericType):
                    logger.warning(
                        f"  ⚠ Aligning numeric type for '{col_name}': {actual_type.simpleString()} -> {expected_type.simpleString()}")
                    output_df = output_df.withColumn(
                        col_name, col(col_name).cast(expected_type))

                # 2b. Block Incompatible Types (e.g., String vs Int)
                else:
                    type_mismatches.append(
                        f"  • {col_name}: INCOMPATIBLE (Expected {expected_type.simpleString()}, got {actual_type.simpleString()})"
                    )

    if added_columns:
        logger.info(
            "ℹ Missing nullable columns found and auto-filled:\n" + "\n".join(added_columns))

    if type_mismatches:
        error_msg = "⚠ Critical schema mismatches found:\n" + \
            "\n".join(type_mismatches)
        logger.error(error_msg)
        # Using TypeError for type-specific failures
        raise TypeError(error_msg)

    # Step 3: Reorder columns to match expected_schema contract exactly
    return output_df.select(*expected_schema.names)


def validate_non_nullable_columns(df: DataFrame, expected_schema: StructType, logger: Logger = default_logger) -> None:
    """Check that non-nullable columns contain no nulls"""
    logger.info("\n  Validating non-nullable columns...")

    non_nullable_columns = [
        field.name for field in expected_schema.fields
        if not field.nullable
    ]

    if not non_nullable_columns:
        logger.info("  ℹ No non-nullable columns defined in schema")
        return

    logger.info(
        f"  Checking {len(non_nullable_columns)} non-nullable columns...")
    # Build condition to find any null in non-nullable columns
    null_condition = py_reduce(
        lambda a, b: a | b,
        [col(c).isNull() for c in non_nullable_columns]
    )

    problematic_rows_df = df.filter(null_condition)
    row_count = problematic_rows_df.count()

    if row_count > 0:
        logger.error(
            f"  ⚠ Found {row_count} rows with nulls in non-nullable columns")

        # Show which columns have nulls
        null_counts = {}
        for col_name in non_nullable_columns:
            null_count = df.filter(col(col_name).isNull()).count()
            if null_count > 0:
                null_counts[col_name] = null_count

        logger.error("\n  Null counts by column:")
        for col_name, count in null_counts.items():
            logger.error(f"    • {col_name}: {count} nulls")

        logger.error("\n  Sample problematic rows:")
        smart_display(problematic_rows_df)

        raise ValueError(
            f"Found {row_count} rows with nulls in non-nullable columns. "
            f"Columns affected: {list(null_counts.keys())}"
        )
    else:
        logger.info(
            f"  ✓ All {len(non_nullable_columns)} non-nullable columns validated")
