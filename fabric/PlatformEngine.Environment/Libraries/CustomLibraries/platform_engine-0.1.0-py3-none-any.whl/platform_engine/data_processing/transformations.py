from pyspark.sql import DataFrame
from pyspark.sql.functions import (
    col, sha2, concat_ws, date_format,
    from_utc_timestamp, hour, minute, lit,
    coalesce 
)
from pyspark.sql.types import IntegerType, StructType


def select_and_cast_columns(
    df: DataFrame,
    rename_map: dict[str, str],
    target_schema: StructType
) -> DataFrame:
    """
    Selects, renames, and casts columns based on a target schema.
    """
    schema_dict = {field.name: field for field in target_schema.fields}
    column_expressions = []

    current_cols = df.columns

    for old_name, new_name in rename_map.items():
        if old_name not in current_cols:
            # Better to catch this early than let Spark throw a generic AnalysisException
            raise KeyError(
                f"Source column '{old_name}' not found in DataFrame.")

        expression = col(old_name).alias(new_name)

        if new_name in schema_dict:
            target_field = schema_dict[new_name]
            expression = expression.cast(target_field.dataType)

        column_expressions.append(expression)

    return df.select(*column_expressions)


def generate_order_item_sk(df: DataFrame) -> DataFrame:
    # 1. Define the business keys that make a row unique
    id_cols = ["order_id", "product_id_platform",
               "variant_id_platform", "order_item_id"]

    # 2. Coalesce nulls to a literal string 'NA' to ensure the hash is deterministic
    # and never returns NULL.
    safe_cols = [coalesce(col(c).cast("string"), lit("NA")) for c in id_cols]

    return df.withColumn(
        "order_item_sk",
        sha2(concat_ws("-", *safe_cols), 256)
    )


def generate_date_columns(df: DataFrame, tz_name: str) -> DataFrame:
    """
    Converts UTC time to local time and extracts SK and time components.
    """
    temp_local_col = "_temp_local_time"

    return (
        df.withColumn(temp_local_col, from_utc_timestamp(
            col("create_time_utc"), tz_name))
        .withColumn(
            "create_local_date_sk",
            date_format(col(temp_local_col), "yyyyMMdd").cast(IntegerType())
        )
        .withColumn("create_hour_local", hour(col(temp_local_col)))
        .withColumn("create_minute_local", minute(col(temp_local_col)))
        .drop(temp_local_col)
    )
