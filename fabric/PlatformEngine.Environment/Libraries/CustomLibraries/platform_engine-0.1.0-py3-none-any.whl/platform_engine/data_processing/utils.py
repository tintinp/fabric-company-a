def smart_display(df, n=20):
    """
    Displays a DataFrame using the best available method 
    for the current environment.
    """
    try:
        # Check if 'display' exists in the global scope (Notebooks)
        from IPython import get_ipython
        if get_ipython() is not None:
            # This looks for the built-in display() available in Fabric/Databricks
            import builtins
            if hasattr(builtins, "display"):
                builtins.display(df)
                return

        # Fallback for local terminal / scripts
        df.show(n, truncate=False)

    except Exception:
        df.show(n)
