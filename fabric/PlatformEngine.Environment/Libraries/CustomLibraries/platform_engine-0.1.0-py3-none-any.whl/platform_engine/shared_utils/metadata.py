import os
import json
import logging
from platform_engine.core.storage_manager import BaseStorageManager
from typing import Dict, List, Tuple


def get_next_version(storage_manager, base_dir: str, logger: logging.Logger) -> int:
    """
    Get the next sequential version number by checking existing versions in directory

    Args:
        storage_manager: Storage manager instance
        base_dir: Base directory path to check for existing versions
        logger: Logger instance

    Returns:
        Next version number (1 if no existing versions found)
    """
    try:
        # Check if directory exists
        if not storage_manager.file_exists(base_dir) and not storage_manager.is_directory(base_dir):
            logger.info(
                f"Base directory does not exist, starting with version 1")
            return 1

        # List directories in base_dir
        items = storage_manager.list_directory(base_dir)

        # Filter for numeric directory names
        version_numbers = []
        for item in items:
            item_path = os.path.join(base_dir, item)
            if storage_manager.is_directory(item_path) and item.isdigit():
                version_numbers.append(int(item))

        if not version_numbers:
            logger.info(f"No existing versions found, starting with version 1")
            return 1

        next_version = max(version_numbers) + 1
        logger.info(
            f"Found existing versions up to {max(version_numbers)}, using version {next_version}")
        return next_version

    except Exception as e:
        logger.warning(
            f"Error checking for existing versions: {e}, defaulting to version 1")
        return 1


def extract_ids_and_fields_from_batches(
    storage_manager,
    directory: str,
    id_field: str,
    additional_fields: List[str],
    logger: logging.Logger
) -> Tuple[List, Dict]:
    """
    Extract IDs and additional fields from all batch JSONL files in directory

    Args:
        storage_manager: Storage manager instance
        directory: Directory containing batch files and metadata.json
        id_field: Field name to extract as ID (e.g., 'order_sn', 'order_id')
        additional_fields: List of additional field names to extract (e.g., ['statuses'])
        logger: Logger instance

    Returns:
        Tuple of (list of IDs, dict mapping ID to dict of additional fields)
    """
    logger.info(
        f"Extracting '{id_field}' and {additional_fields} from batches in {directory}")

    try:
        # Read metadata to get list of output files
        metadata_path = os.path.join(directory, 'metadata.json')
        metadata_content = storage_manager.read_file(metadata_path)
        metadata = json.loads(metadata_content)

        output_files = metadata.get('output_files', [])
        if not output_files:
            logger.warning(f"No output files found in metadata")
            return [], {}

        all_ids = []
        id_to_fields = {}

        for batch_file in output_files:
            file_path = os.path.join(directory, batch_file)
            logger.info(f"Reading records from {file_path}")

            try:
                content = storage_manager.read_file(file_path)
                for line in content.strip().split('\n'):
                    if line:
                        record = json.loads(line)
                        if id_field in record:
                            record_id = record[id_field]
                            all_ids.append(record_id)

                            # Extract additional fields
                            extracted_data = {}
                            for field in additional_fields:
                                if field in record:
                                    extracted_data[field] = record[field]
                                else:
                                    logger.warning(
                                        f"Record missing '{field}' field for ID {record_id}")
                            id_to_fields[record_id] = extracted_data
                        else:
                            logger.warning(
                                f"Record missing '{id_field}' field: {record}")
            except Exception as e:
                logger.error(f"Error reading batch file {file_path}: {e}")
                raise

        logger.info(
            f"Extracted {len(all_ids)} IDs and fields from {len(output_files)} batch files")
        return all_ids, id_to_fields

    except Exception as e:
        logger.error(f"Error extracting data from batches: {e}")
        raise


def extract_ids_from_batches(
    storage_manager,
    directory: str,
    id_field: str,
    logger: logging.Logger
) -> List:
    """
    Extract IDs from all batch JSONL files in directory

    Args:
        storage_manager: Storage manager instance
        directory: Directory containing batch files and metadata.json
        id_field: Field name to extract (e.g., 'order_sn', 'order_id')
        logger: Logger instance

    Returns:
        List of extracted IDs
    """
    logger.info(f"Extracting '{id_field}' from batches in {directory}")

    try:
        # Read metadata to get list of output files
        metadata_path = os.path.join(directory, 'metadata.json')
        metadata_content = storage_manager.read_file(metadata_path)
        metadata = json.loads(metadata_content)

        output_files = metadata.get('output_files', [])
        if not output_files:
            logger.warning(f"No output files found in metadata")
            return []

        all_ids = []
        for batch_file in output_files:
            file_path = os.path.join(directory, batch_file)
            logger.info(f"Reading IDs from {file_path}")

            try:
                content = storage_manager.read_file(file_path)
                for line in content.strip().split('\n'):
                    if line:
                        record = json.loads(line)
                        if id_field in record:
                            all_ids.append(record[id_field])
                        else:
                            logger.warning(
                                f"Record missing '{id_field}' field: {record}")
            except Exception as e:
                logger.error(f"Error reading batch file {file_path}: {e}")
                raise

        logger.info(
            f"Extracted {len(all_ids)} IDs from {len(output_files)} batch files")
        return all_ids

    except Exception as e:
        logger.error(f"Error extracting IDs from batches: {e}")
        raise


def validate_source_metadata(
    storage_manager: BaseStorageManager,
    directory: str,
    logger: logging.Logger,
) -> Dict:
    """
    Validate metadata from a source directory

    Args:
        storage_manager: Storage manager instance
        directory: Directory path containing metadata.json
        logger: Logger instance

    Returns:
        Metadata dictionary if valid

    Raises:
        Exception if metadata is invalid or has errors
    """
    logger.info(f"Validating metadata in: {directory}")

    metadata_path = os.path.join(directory, 'metadata.json')

    try:
        # Read metadata
        metadata_content = storage_manager.read_file(metadata_path)
        metadata = json.loads(metadata_content)
    except FileNotFoundError:
        raise Exception(f"Metadata file not found: {metadata_path}")
    except Exception as e:
        raise Exception(f"Failed to read metadata from {metadata_path}: {e}")

    # Check status
    status = metadata.get('status')
    if status != 'completed':
        raise Exception(
            f"Source directory has invalid status: '{status}' (expected 'completed'). "
            f"Directory: {directory}"
        )

    # Check for validation errors (any non-empty list in validation)
    validation = metadata.get('validation', {})
    validation_errors = []

    for key, value in validation.items():
        if isinstance(value, list) and len(value) > 0:
            validation_errors.append(f"{key}: {len(value)} items")
            logger.warning(
                f"Validation issue found - {key}: {len(value)} items")

    # Raise exception if any validation errors found
    if validation_errors:
        raise Exception(
            f"Source directory has validation errors: {', '.join(validation_errors)}. "
            f"Directory: {directory}"
        )

    logger.info(
        f"Metadata validation passed: {metadata.get('total_records', 0)} records, "
        f"{metadata.get('total_batches', 0)} batches"
    )

    return metadata


def get_ids_from_source(
        storage_manager: BaseStorageManager,
        source_dir: str,
        id_field_name: str,
        logger: logging.Logger,
) -> List[str]:

    validate_source_metadata(storage_manager, source_dir, logger)

    ids = extract_ids_from_batches(
        storage_manager, source_dir, id_field_name, logger)

    if not ids:
        logger.warning(f"No {id_field_name}s found in source data.")
        return []

    logger.info(
        f"Target: {len(ids)} IDs identified for processing from {source_dir}")

    return ids
