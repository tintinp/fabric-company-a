import re
import json
import os
from datetime import datetime, timedelta
from logging import Logger
from platform_engine.core.storage_manager import BaseStorageManager
from typing import List, Tuple, Dict
from platform_engine.shared_utils.metadata import validate_source_metadata, get_next_version
from platform_engine.shared_utils.platform_api_name import get_order_list_api_name


def format_directory_suffix(created_after: str, created_before: str, epoch: int) -> str:
    """
    Generates the standardized directory name suffix.
    Format: YYYY-MM-DD_YYYY-MM-DD_EPOCH
    """
    start = datetime.fromisoformat(created_after)
    end = datetime.fromisoformat(created_before)

    # Inclusive end date for folder naming (subtract 1 day from exclusive end)
    end_inclusive = end - timedelta(days=1)

    return f"{start.strftime('%Y-%m-%d')}_{end_inclusive.strftime('%Y-%m-%d')}_{epoch}"


def derive_output_directory_from_source(
    storage_manager: BaseStorageManager,
    source_metadata_path: str,
    output_api_name: str,
    base_output_dir: str,
    logger
) -> Tuple[str, str, str, str, str, str]:
    """
    Derives output directory for a new query type by parsing source metadata path

    Args:
        storage_manager: Storage manager instance
        source_metadata_path: Path to source metadata.json file
        output_api_name: New query type (e.g., 'order_detail', 'finance')
        base_output_dir: Base output directory (e.g., 'data')
        logger: Logger instance

    Returns:
        Tuple of (full_output_dir, source_dir, created_after, created_before, frequency, platform)

    Example:
        Source output_directory: data/monthly/shopee/order_list/2025_04/1/
        New query_type: 'order_detail'
        Result: data/monthly/shopee/order_detail/2025_04/1/ (with auto-incremented version)
    """
    logger.info(
        f"Deriving output directory from source: {source_metadata_path}")

    # Determine if path is to metadata file or directory
    if source_metadata_path.endswith('metadata.json'):
        metadata_dir = os.path.dirname(source_metadata_path)
    else:
        metadata_dir = source_metadata_path

    # Validate source metadata
    source_metadata = validate_source_metadata(
        storage_manager,
        metadata_dir,
        logger,
    )

    # Extract required fields
    source_directory = source_metadata.get('output_directory')
    if not source_directory:
        source_directory = metadata_dir

    config_data = source_metadata.get('config', {})
    frequency = config_data.get('frequency', None)
    if not frequency:
        raise Exception("Source metadata missing 'frequency' field")

    platform = config_data.get('platform', None)
    if not platform:
        raise Exception("Source metadata missing 'platform' field")

    created_after = config_data.get('created_after', None)
    created_before = config_data.get('created_before', None)

    if not created_after or not created_before:
        raise Exception("Source metadata missing date_range")

    # Parse source output directory to extract structure
    # Example: data/monthly/shopee/order_list/2025_04/1
    # Structure: base/frequency/platform/query_type/date/version
    path_parts = source_directory.rstrip('/').split('/')

    # Find the index of the source query_type and extract date
    if len(path_parts) < 3:
        raise Exception(
            f"Invalid source output directory structure: {source_directory}")

    # Extract date (should be 2 parts before the end: date/version)
    directory_date = path_parts[-2]  # e.g., '2025_04'

    # Build new directory path: base/frequency/platform/output_api_name/date
    base_dir_without_version = os.path.join(
        base_output_dir,
        frequency,
        platform,
        output_api_name,
        directory_date
    )

    # Get next version
    version = get_next_version(
        storage_manager, base_dir_without_version, logger)

    # Build full output directory
    full_output_dir = os.path.join(base_dir_without_version, str(version))

    logger.info(
        f"Derived output directory: {full_output_dir} (version {version})")

    return full_output_dir, source_directory, created_after, created_before, frequency, platform


def parse_input_date(input_arg: str) -> Tuple[str, str]:
    """
    Parse input date argument and determine frequency type

    Args:
        input_arg: Date string in one of these formats:
            - "2025-04" -> monthly
            - "2025-04-01" -> daily
            - "2025-04-01-2025-04-05" -> custom

    Returns:
        Tuple of (frequency, date_folder)

    Examples:
        >>> parse_input_date("2025-04")
        ('monthly', '2025_04')
        >>> parse_input_date("2025-04-01")
        ('daily', '2025_04_01')
        >>> parse_input_date("2025-04-01-2025-04-05")
        ('custom', '2025_04_01-2025_04_05')
    """
    # Monthly: YYYY-MM
    if re.match(r'^\d{4}-\d{2}$', input_arg):
        return 'monthly', input_arg.replace('-', '_')

    # Daily: YYYY-MM-DD
    elif re.match(r'^\d{4}-\d{2}-\d{2}$', input_arg):
        return 'daily', input_arg.replace('-', '_')

    # Custom: YYYY-MM-DD-YYYY-MM-DD
    elif re.match(r'^\d{4}-\d{2}-\d{2}-\d{4}-\d{2}-\d{2}$', input_arg):
        # Replace only the first 3 dashes with underscores, keep the middle dash
        parts = input_arg.split('-')
        date_folder = f"{parts[0]}_{parts[1]}_{parts[2]}-{parts[3]}_{parts[4]}_{parts[5]}"
        return 'custom', date_folder

    else:
        raise ValueError(
            f"Invalid input date format: '{input_arg}'. "
            f"Expected formats: 'YYYY-MM' (monthly), 'YYYY-MM-DD' (daily), "
            f"or 'YYYY-MM-DD-YYYY-MM-DD' (custom)"
        )


def get_lastest_valid_source_dir(
    storage_manager: BaseStorageManager,
    base_path: str,
    frequency: str,
    platform: str,
    api_name: str,
    date_folder: str,
    logger: Logger
) -> str:
    """
    Get the latest valid version path by checking versions from newest to oldest

    This function finds the latest version that has valid metadata (status='completed',
    no validation errors). If the latest version has errors, it falls back to
    previous versions automatically.

    Args:
        storage_manager: Storage manager instance
        base_path: Base path to search
        frequency: Frequency type ('monthly', 'daily', 'custom')
        platform: Platform name
        api_name: API name 
        date_folder: Date folder name
        logger: Logger instance

    Returns:
        Full path to the latest valid version directory

    Raises:
        ValueError: If no valid versions are found
    """
    full_path = os.path.join(base_path, frequency,
                             platform, api_name, date_folder)

    try:
        # List directories
        items = storage_manager.list_directory(full_path)

        # Filter for numeric directory names (versions) and sort descending
        versions = []
        for item in items:
            if item.isdigit():
                versions.append(int(item))

        if not versions:
            raise ValueError(
                f"No versions found for {platform}/{api_name} at {full_path}"
            )

        # Sort versions from newest to oldest
        versions.sort(reverse=True)
        logger.info(
            f"Found {len(versions)} version(s) at {full_path}: {versions}")

        # Try each version from latest to oldest
        for version in versions:
            version_path = os.path.join(full_path, str(version))
            logger.info(f"Checking version {version}...")

            try:
                # Try to validate metadata for this version
                validate_source_metadata(
                    storage_manager=storage_manager,
                    directory=version_path,
                    logger=logger,
                )

                # If validation succeeds, this is our latest valid version
                logger.info(
                    f"✓ Version {version} is valid - using this version")
                return version_path

            except Exception as e:
                # This version is invalid, try the next one
                logger.warning(f"✗ Version {version} is invalid: {e}")
                continue

        # If we get here, no valid versions were found
        raise ValueError(
            f"No valid versions found for {platform}/{api_name} at {full_path}. "
            f"Checked versions: {versions}"
        )

    except Exception as e:
        logger.error(f"Error finding latest valid version at {full_path}: {e}")
        raise


def discover_data_paths(
    storage_manager,
    input_date: str,
    platform: str,
    base_path: str,
    api_names: List[str],
    logger: Logger,
) -> Dict[str, str]:
    """
    Discover and validate data directories for all APIs based on input date

    This function finds the latest version directory for each API and validates
    that the metadata.json exists and is valid. It returns just the directory paths -
    use get_batch_file_paths() to get the full paths to batch files from metadata.

    Args:
        storage_manager: Storage manager instance
        input_date: Date string (e.g., "2025-04", "2025-04-01")
        platform: Platform name ('lazada', 'shopee')
        base_path: Base path (e.g., "abfss://...@.../Files")
        api_names: List of API names to discover (e.g., ['order_list', 'order_items', 'finance'])
        logger: Logger instance

    Returns:
        Dictionary mapping API name to validated directory path:
        {
            'order_list': 'abfss://.../Files/monthly/lazada/order_list/2025_04/1',
            'order_items': 'abfss://.../Files/monthly/lazada/order_items/2025_04/1',
            'finance': 'abfss://.../Files/monthly/lazada/finance/2025_04/1'
        }

    Example:
        >>> paths = discover_data_paths(
        ...     storage_manager=storage_manager,
        ...     input_date="2025-04",
        ...     platform="lazada",
        ...     base_path="abfss://...@.../Files",
        ...     api_names=["order_list", "order_items", "finance"],
        ...     logger=logger
        ... )
        >>> order_list_dir = paths['order_list']
        >>> batch_files = get_batch_file_paths(storage_manager, order_list_dir)
    """

    logger.info("=" * 80)
    logger.info(f"Discovering data paths for {platform} - {input_date}")
    logger.info("=" * 80)

    # Parse input date to get frequency and date folder
    frequency, date_folder = parse_input_date(input_date)
    logger.info(f"Detected frequency: {frequency}, date folder: {date_folder}")

    result = {}

    for api_name in api_names:
        logger.info(f"\nDiscovering {api_name}...")

        try:
            # Find latest valid version
            # (validation happens inside get_lastest_valid_source_dir)
            source_dir = get_lastest_valid_source_dir(
                storage_manager=storage_manager,
                base_path=base_path,
                frequency=frequency,
                platform=platform,
                api_name=api_name,
                date_folder=date_folder,
                logger=logger
            )

            # Just store the validated directory path
            result[api_name] = source_dir

            # Read metadata for logging purposes
            metadata_path = os.path.join(source_dir, 'metadata.json')
            metadata_content = storage_manager.read_file(metadata_path)
            metadata = json.loads(metadata_content)

            logger.info(f"  ✓ Version: {os.path.basename(source_dir)}")
            logger.info(f"  ✓ Path: {source_dir}")
            logger.info(
                f"  ✓ Batch files: {len(metadata.get('output_files', []))}")
            logger.info(
                f"  ✓ Total records: {metadata.get('total_records', 0)}")

        except Exception as e:
            logger.error(f"  ✗ Failed to discover {api_name}: {e}")
            raise

    logger.info("\n" + "=" * 80)
    logger.info(f"Successfully discovered {len(result)} data sources")
    logger.info("=" * 80)

    return result


def get_batch_file_paths(
    storage_manager: BaseStorageManager,
    directory_path: str,
    logger: Logger
) -> List[str]:
    """
    Get full paths to all batch files from a validated directory

    Reads metadata.json from the directory and constructs full paths to all batch files
    listed in the output_files field.

    Args:
        storage_manager: Storage manager instance
        directory_path: Full path to directory containing metadata.json and batch files
        logger: Logger instance

    Returns:
        List of full paths to batch files

    Example:
        >>> paths = discover_data_paths(storage_manager, "2025-04", "lazada", "abfss://.../Files", ["order_list"], logger)
        >>> order_list_dir = paths['order_list']
        >>> batch_files = get_batch_file_paths(storage_manager, order_list_dir, logger)
        >>> print(batch_files)
        ['abfss://.../Files/monthly/lazada/order_list/2025_04/1/batch_0001.jsonl',
         'abfss://.../Files/monthly/lazada/order_list/2025_04/1/batch_0002.jsonl']
    """
    # Read metadata from directory
    metadata_path = os.path.join(directory_path, 'metadata.json')

    try:
        metadata_content = storage_manager.read_file(metadata_path)
        metadata = json.loads(metadata_content)
    except Exception as e:
        logger.error(f"Failed to read metadata from {metadata_path}: {e}")
        raise

    # Get batch files list
    batch_files = metadata.get('output_files', [])

    if not batch_files:
        logger.warning(
            f"No output files found in metadata at {directory_path}")
        return []

    # Construct full paths
    full_paths = [
        os.path.join(directory_path, batch_file)
        for batch_file in batch_files
    ]

    logger.info(f"Found {len(full_paths)} batch files in {directory_path}")

    return full_paths


def resolve_source_and_output_paths(storage, args, source_api_name: str, output_api_name: str, logger) -> Tuple[str, str, str, str, str]:
    """
    Resolve source metadata path and derive output directory for finance data.
    """
    import os
    from platform_engine.shared_utils.directory import (
        derive_output_directory_from_source,
        get_lastest_valid_source_dir,
        parse_input_date
    )

    if not args.output_dir:
        args.output_dir = os.path.join(os.getcwd(), 'data')
        logger.info(f"Using default output directory: {args.output_dir}")

    # 1. Source Discovery
    if args.source_metadata_path:
        logger.info(f"Using explicit source path: {args.source_metadata_path}")
        source_metadata_path = args.source_metadata_path
    else:
        logger.info(
            f"Auto-discovering source order_list for date: {args.date}")
        try:
            frequency, date_folder = parse_input_date(args.date)
            source_metadata_path = get_lastest_valid_source_dir(
                storage_manager=storage,
                base_path=args.output_dir,
                frequency=frequency,
                platform=args.platform,
                api_name=source_api_name,
                date_folder=date_folder,
                logger=logger
            )
        except Exception as e:
            logger.error(f"Discovery failed: {e}")
            raise

    # 2. Derive Output Path
    try:
        # We look for 'order_list' as source and 'transaction_details' as output
        full_output_dir, source_orders_dir, created_after, created_before, frequency, platform = \
            derive_output_directory_from_source(
                storage,
                source_metadata_path,
                output_api_name,
                args.output_dir,
                logger
            )
    except Exception as e:
        logger.error(f"Output derivation failed: {e}")
        raise

    logger.info(f"Source: {source_orders_dir}")
    logger.info(f"Output: {full_output_dir}")

    return (source_orders_dir, full_output_dir, platform, created_after, created_before)
