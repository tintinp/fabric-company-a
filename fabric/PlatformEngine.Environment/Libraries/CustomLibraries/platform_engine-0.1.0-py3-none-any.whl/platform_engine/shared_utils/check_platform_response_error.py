from typing import Any


def check_shopee_response_error(response: Any):
    error = response.get('error')
    request_id = response.get('request_id')

    if error:
        message = response.get('message', 'No error message')
        # Trigger retry for busy or server errors
        if error in ['error_server', 'error_busy']:
            raise ConnectionError(
                f"Shopee API Busy: Request ID: {request_id} - Error: {error} - Message: {message}"
            )
        raise ValueError(
            f"Shopee API Error: Request ID: {request_id} - Error: {error} - Message: {message}"
        )


def check_lazada_response_error(response: Any):
    message = response.get('message')
    request_id = response.get('request_id')
    code = response.get('code')

    if code != '0':
        message = response.get('message', 'No error message')
        raise ValueError(
            f"Lazada API Error: Request ID: {request_id} - Code: {code} - Message: {message}"
        )
