#!/usr/bin/env python3
from datetime import datetime, timedelta
from typing import List, Tuple


def split_date_range_into_chunks(
    created_after: str,
    created_before: str,
    max_days: int = 15
) -> List[Tuple[int, int]]:
    """
    Splits an ISO 8601 date range into chunks of Unix timestamps.

    Args:
        created_after: ISO format string (e.g., 2025-01-01T00:00:00+07:00)
        created_before: ISO format string (Exclusive end)
        max_days: Maximum number of days per chunk

    Returns:
        List of tuples: [(chunk_start_timestamp, chunk_end_timestamp), ...]
    """
    # Parse ISO 8601 strings.
    # Note: Using fromisoformat handles +HH:MM timezone offsets.
    start_dt = datetime.fromisoformat(created_after)
    end_dt = datetime.fromisoformat(created_before)

    if start_dt >= end_dt:
        raise ValueError(
            f"Start date ({created_after}) must be before end date ({created_before})")

    chunks: List[Tuple[int, int]] = []
    current_cursor = start_dt

    while current_cursor < end_dt:
        # Calculate the potential end of this chunk
        chunk_end = min(current_cursor + timedelta(days=max_days), end_dt)

        # Convert to Unix timestamps (integers)
        chunks.append((
            int(current_cursor.timestamp()),
            int(chunk_end.timestamp())
        ))

        # Move the cursor to the end of the current chunk
        current_cursor = chunk_end

    return chunks
