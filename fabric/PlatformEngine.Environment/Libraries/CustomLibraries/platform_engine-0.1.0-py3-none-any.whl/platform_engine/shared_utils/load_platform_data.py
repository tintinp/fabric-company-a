from pyspark.sql import DataFrame, SparkSession
from typing import Dict, List
from logging import Logger

from platform_engine.core.metadata_manager import StorageManager
from platform_engine.shared_utils.directory import discover_data_paths

def load_platform_data(
    spark: SparkSession,
  input_date: str,
    platform: str,
    base_path: str,
    api_names: List[str],
    logger: Logger
) -> Dict[str, DataFrame]:
    """
    Discover and load data for all specified APIs into Spark DataFrames

    This function:
    1. Discovers the latest validated version directories for each API
    2. Reads all batch files using wildcard pattern (efficient for Spark)
    3. Returns combined DataFrame per API
    4. Validates metadata (status='completed', no errors) automatically

    Args:
        spark: SparkSession instance
        storage_manager: Storage manager instance
        input_date: Date string (e.g., "2025-04", "2025-04-01")
        platform: Platform name ('lazada', 'shopee')
        base_path: Base path (e.g., "abfss://...@.../Files")
        api_names: List of platform-specific API names
            - For Lazada: ['orders', 'order_items', 'transaction_details']
            - For Shopee: ['order_list', 'order_details', 'escrow_details']
        logger: Logger instance

    Returns:
        Dictionary mapping API name to Spark DataFrame:
        For Lazada:
        {
            'orders': DataFrame,
            'order_items': DataFrame,
            'transaction_details': DataFrame
        }
        For Shopee:
        {
            'order_list': DataFrame,
            'order_details': DataFrame,
            'escrow_details': DataFrame
        }
    """

    logger.info("\n" + "=" * 80)
    logger.info(f"Loading data for {platform} - {input_date}")
    logger.info("=" * 80)

    # Discover and validate directory paths
    # This finds the latest valid version for each API
    logger.info("\nDiscovering data paths...")
    data_paths = discover_data_paths(
        storage_manager=storage_manager,
        input_date=input_date,
        platform=platform,
        base_path=base_path,
        api_names=api_names,
        logger=logger
    )

    # Load data using wildcard pattern (efficient for Spark)
    logger.info("\nLoading data into DataFrames...")
    result = {}

    for api_name in api_names:
        logger.info(f"\nLoading {api_name}...")

        try:
            # Get directory path
            directory_path = data_paths[api_name]

            # Read all JSONL files in directory using wildcard
            # Spark optimizes this to read all files efficiently
            wildcard_path = f"{directory_path}/batch_*.jsonl"
            logger.info(f"Reading from: {wildcard_path}")

            df = spark.read.json(wildcard_path)
            record_count = df.count()

            result[api_name] = df
            logger.info(f"  ✓ Loaded {record_count} records")

        except Exception as e:
            logger.error(f"  ✗ Failed to load {api_name}: {e}")
            raise

    logger.info("\n" + "=" * 80)
    logger.info(f"Successfully loaded {len(result)} DataFrames")
    logger.info("=" * 80 + "\n")

    return result
