import os
from typing import Any

VAULT_NAME = "PlatformCreds"
KV_URI = f"https://{VAULT_NAME}.vault.azure.net"


def get_secret(key: str, default: Any = None) -> str:
    try:
        from notebookutils import mssparkutils
    except (ImportError, Exception):
        return os.getenv(key, default)

    return mssparkutils.credentials.getSecret(KV_URI, key.replace("_", "-"))
