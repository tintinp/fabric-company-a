#!/usr/bin/env python3
"""
Shared logging utilities for data extraction scripts
"""

import logging


def setup_logger(logger_name: str, log_file: str = None, console_level: int = logging.INFO, file_level: int = logging.DEBUG) -> logging.Logger:
    """
    Setup logging configuration with console and file handlers

    Args:
        logger_name: Name for the logger
        log_file: Path to log file (optional)
        console_level: Logging level for console output (default: INFO)
        file_level: Logging level for file output (default: DEBUG)

    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)

    # Clear existing handlers to avoid duplicates
    logger.handlers.clear()

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(console_level)

    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # File handler (optional)
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(file_level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger
