#!/usr/bin/env python3
"""
Common Argument Utilities
Shared argument parsing, validation, and logger setup for data extraction modules
"""

import logging
import argparse
from typing import Any, Dict
from platform_engine.shared_utils.logger import setup_logger as _setup_logger


def get_default_params() -> Dict[str, Any]:
    """
    Returns default parameters mirroring the argparse defaults.
    This serves as the 'Source of Truth' for Fabric Notebooks.
    """
    return {
        # Common arguments
        "platform": None,
        "output_dir": None,
        "request_delay": 1.0,
        "max_retries": 5,
        "retry_backoff_factor": 2.0,
        "batch_size_mb": 10.0,
        "storage_type": None,
        "timeout_seconds": 480,
        "log_file": None,
        # Order list arguments
        "frequency": "daily",
        "month": None,
        "date": None,
        "timezone": "Asia/Bangkok",
        "created_after": None,
        "created_before": None,
        "shp_page_size": 100,
        "shp_query_range_days": 11,
        "lzd_orders_limit": 100,
        "ignore_empty_list": False,
        # Order details arguments
        "shp_batch_size": 50,
        "lzd_batch_size": 50,
        # Transaction details arguments
        "shp_escrow_details_batch_size": 50,
        "lzd_transactions_limit": 100,
        "lzd_date_buffer_days": 15,
    }


def setup_logger(platform: str, module_type: str, log_file: str = None) -> logging.Logger:
    """
    Setup logging configuration for data extraction modules

    Args:
        platform: Platform name (e.g., 'lazada', 'shopee')
        module_type: Module type suffix (e.g., 'OrderListFetcher', 'OrderDetailsFetcher')
        log_file: Optional log file path

    Returns:
        Configured logger instance
    """
    logger_name = f'{platform.capitalize()}{module_type}'
    return _setup_logger(logger_name, log_file)


def add_common_arguments(parser: argparse.ArgumentParser) -> None:
    """
    Add common CLI arguments shared across data extraction scripts

    Args:
        parser: ArgumentParser instance to add arguments to
    """
    defaults = get_default_params()

    parser.add_argument(
        '--platform',
        required=True,
        choices=['lazada', 'shopee'],
        help='Platform to fetch data from'
    )

    parser.add_argument(
        '--output-dir',
        default=defaults['output_dir'],
        help='Output directory for data files'
    )
    parser.add_argument(
        '--request-delay',
        type=float,
        default=defaults['request_delay'],
        help='Delay between API requests in seconds'
    )
    parser.add_argument(
        '--max-retries',
        type=int,
        default=defaults['max_retries'],
        help='Maximum number of retries for failed requests'
    )
    parser.add_argument(
        '--retry-backoff-factor',
        type=float,
        default=defaults['retry_backoff_factor'],
        help='Exponential backoff factor for retries'
    )
    parser.add_argument(
        '--batch-size-mb',
        type=float,
        default=defaults['batch_size_mb'],
        help='Target batch size in MB for output files'
    )
    parser.add_argument(
        '--storage-type',
        choices=['local', 'onelake'],
        default=defaults['storage_type'],
        help='Storage type (auto-detected if not specified)'
    )
    parser.add_argument(
        '--timeout-seconds',
        type=int,
        default=defaults['timeout_seconds'],
        help='Timeout in seconds (default: 480 = 8 minutes)'
    )
    parser.add_argument(
        '--log-file',
        default=defaults['log_file'],
        help='Log file path'
    )


def validate_source_metadata_args(args: argparse.Namespace) -> None:
    """
    Validate mutually exclusive source-metadata-path and date arguments

    Args:
        args: Parsed arguments

    Raises:
        ValueError: If invalid argument combination
    """
    if not args.source_metadata_path and not args.date:
        raise ValueError(
            "Either --source-metadata-path or --date must be provided")

    if args.source_metadata_path and args.date:
        raise ValueError(
            "--source-metadata-path and --date are mutually exclusive")
