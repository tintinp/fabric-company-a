def get_order_list_api_name(platform: str) -> str:
    if platform.lower() == 'shopee':
        return 'order_list'
    elif platform.lower() == 'lazada':
        return 'orders'
    else:
        raise ValueError(f"Unsupported platform: {platform}")


def get_order_details_api_name(platform: str) -> str:
    if platform.lower() == 'shopee':
        return 'order_details'
    elif platform.lower() == 'lazada':
        return 'order_items'
    else:
        raise ValueError(f"Unsupported platform: {platform}")


def get_transaction_details_api_name(platform: str) -> str:
    if platform.lower() == 'shopee':
        return 'escrow_details'
    elif platform.lower() == 'lazada':
        return 'transactions'
    else:
        raise ValueError(f"Unsupported platform: {platform}")
