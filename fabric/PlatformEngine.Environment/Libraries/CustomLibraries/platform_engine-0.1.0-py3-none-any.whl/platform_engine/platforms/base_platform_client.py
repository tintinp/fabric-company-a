#!/usr/bin/env python3
"""
Base Platform Client - Core Transport Layer (Type-Safe Version)
"""

from dataclasses import dataclass
import time
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, TypeVar, Generic, TypedDict, Callable
import requests

from platform_engine.shared_utils.script_setup import get_default_params

_defaults = get_default_params()


@dataclass
class PlatformConfig:
    request_delay: float = _defaults['request_delay']
    max_retries: int = _defaults['max_retries']
    retry_backoff_factor: float = _defaults['retry_backoff_factor']
    timeout_seconds: int = _defaults['timeout_seconds']


T = TypeVar('T', bound=PlatformConfig)
ResponseValidator = Callable[[Dict[str, Any]], None]


class SignResult(TypedDict):
    """The expected structure for platform-specific signing"""
    url: str
    headers: Dict[str, str]
    params: Dict[str, Any]


class BasePlatformClient(ABC, Generic[T]):
    """
    Abstract Base Class for all Platform APIs.
    Uses Generic[T] to provide type safety for platform-specific configs.
    """

    def __init__(self, config: T, logger: logging.Logger):
        self.config = config
        self.logger = logger
        self.last_request_time = 0.0
        self.start_time = time.time()
        self.session = requests.Session()

    @abstractmethod
    def _sign_request(
        self,
        method: str,
        path: str,
        params: Dict[str, Any],
        body: Optional[Any]
    ) -> SignResult:
        """
        Subclasses must return a SignResult dict.
        IDE will now alert if keys like 'url' or 'headers' are missing.
        """
        pass

    def _wait_for_rate_limit(self) -> None:
        elapsed = time.time() - self.last_request_time
        if elapsed < self.config.request_delay:
            sleep_time = self.config.request_delay - elapsed
            self.logger.debug(f"Rate limiting: sleeping for {sleep_time:.2f}s")
            time.sleep(sleep_time)

    def _check_timeout(self) -> bool:
        elapsed = time.time() - self.start_time
        if elapsed > self.config.timeout_seconds:
            self.logger.error(
                f"Global timeout: {elapsed:.1f}s / {self.config.timeout_seconds}s"
            )
            return True
        return False

    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        body: Optional[Any] = None,
        validator: Optional[ResponseValidator] = None  # New optional arg
    ) -> Dict[str, Any]:

        safe_params = params or {}

        def operation():
            response = self._perform_http_call(method, path, safe_params, body)

            # If a validator is provided, run it.
            # If it raises an exception, the retry loop will catch it.
            if validator:
                validator(response)

            return response

        return self._execute_with_retry(operation)

    def _perform_http_call(
        self,
        method: str,
        path: str,
        params: Dict[str, Any],
        body: Optional[Any]
    ) -> Dict[str, Any]:
        """Internal helper to execute a single request attempt"""
        if self._check_timeout():
            raise TimeoutError("Execution exceeded config.timeout_seconds")

        self._wait_for_rate_limit()

        # Signing contract is now strictly typed
        context: SignResult = self._sign_request(method, path, params, body)

        self.last_request_time = time.time()
        response = self.session.request(
            method=method,
            url=context['url'],
            headers=context['headers'],
            params=context['params'],
            json=body if method in ['POST', 'PUT', 'PATCH'] else None,
            timeout=30
        )

        if response.status_code != 200:
            self.logger.error(f"HTTP {response.status_code}: {response.text}")
            response.raise_for_status()

        # Standard API response is usually a Dict
        return response.json()

    def _execute_with_retry(self, func: Callable[[], Dict[str, Any]]) -> Dict[str, Any]:
        """Standardized retry engine with explicit type hints"""
        last_exception: Exception = Exception("Unknown error")

        for attempt in range(self.config.max_retries + 1):
            try:
                return func()
            except Exception as e:
                last_exception = e
                if attempt < self.config.max_retries:
                    backoff = self.config.request_delay * \
                        (self.config.retry_backoff_factor ** attempt)
                    self.logger.warning(
                        f"Attempt {attempt + 1}/{self.config.max_retries} failed: {e}. Retrying in {backoff:.2f}s..."
                    )
                    time.sleep(backoff)
                else:
                    self.logger.error(f"Final attempt failed: {e}")
                    raise last_exception

        raise last_exception
