#!/usr/bin/env python3
"""
Shopee API Client Implementation
Concrete implementation of the BasePlatformClient for Shopee's Open API v2.
"""

from dataclasses import dataclass, asdict
import hmac
import hashlib
import os
import time
from typing import Dict, Any, Optional

from platform_engine.platforms.base_platform_client import BasePlatformClient, SignResult, PlatformConfig
from platform_engine.shared_utils.get_secret import get_secret

# Constants for Shopee
SHOPEE_PROD_URL = 'https://partner.shopeemobile.com'


@dataclass
class ShopeeClientConfig(PlatformConfig):
    shop_id: int = None
    partner_id: int = None
    partner_key: str = None
    access_token: str = None
    refresh_token: str = None


def build_shopee_client_config(base_config: PlatformConfig) -> ShopeeClientConfig:
    """Build ShopeeClientConfig from a base PlatformConfig and environment variables."""
    return ShopeeClientConfig(
        **asdict(base_config),
        access_token=get_secret("SHOPEE_ACCESS_TOKEN", ""),
        refresh_token=get_secret("SHOPEE_REFRESH_TOKEN", ""),
        shop_id=int(get_secret("SHOPEE_SHOP_ID", 0)),
        partner_id=int(get_secret("SHOPEE_PARTNER_ID", 0)),
        partner_key=get_secret("SHOPEE_PARTNER_KEY", "")
    )


class ShopeeClient(BasePlatformClient[ShopeeClientConfig]):
    """
    Handles Shopee-specific authentication and protocol details.
    """

    def _sign_request(
        self,
        method: str,
        path: str,
        params: Dict[str, Any],
        body: Optional[Any]
    ) -> SignResult:
        """
        Implementation of the Shopee v2 signing algorithm.
        Refactored from the original shopee_send logic.
        """
        timestamp = int(time.time())

        # 1. Generate the base string for signing
        # Format: {partner_id}{path}{timestamp}{access_token}{shop_id}
        base_string = (
            f"{self.config.partner_id}"
            f"{path}"
            f"{timestamp}"
            f"{self.config.access_token}"
            f"{self.config.shop_id}"
        ).encode()

        # 2. HMAC-SHA256 signature
        partner_key = self.config.partner_key.encode()
        sign = hmac.new(partner_key, base_string, hashlib.sha256).hexdigest()

        # 3. Construct common parameters required for every Shopee call
        common_params = {
            'partner_id': self.config.partner_id,
            'timestamp': timestamp,
            'access_token': self.config.access_token,
            'shop_id': self.config.shop_id,
            'sign': sign,
        }

        # 4. Merge with user-provided parameters
        final_params = {**common_params, **params}

        # 5. Build final URL
        url = f"{SHOPEE_PROD_URL}{path}"

        return SignResult(
            url=url,
            headers={"Content-Type": "application/json"},
            params=final_params
        )
