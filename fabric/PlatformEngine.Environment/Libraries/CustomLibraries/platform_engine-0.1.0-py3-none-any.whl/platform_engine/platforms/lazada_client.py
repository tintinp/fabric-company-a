#!/usr/bin/env python3
"""
Lazada API Client Implementation
Adapts the Lazada SDK to our BasePlatformClient contract.
"""

from dataclasses import dataclass, asdict
import json
import os
import time
from typing import Dict, Any, Optional
from platform_engine.platforms.lazada_sdk import LazopClient, LazopRequest
from platform_engine.platforms.base_platform_client import BasePlatformClient, SignResult, PlatformConfig
from platform_engine.shared_utils.get_secret import get_secret


@dataclass
class LazadaClientConfig(PlatformConfig):
    app_key: str = None
    app_secret: str = None
    access_token: str = None
    refresh_token: str = None


def build_lazada_client_config(base_config: PlatformConfig) -> LazadaClientConfig:
    """Build LazadaClientConfig from a base PlatformConfig and environment variables."""
    return LazadaClientConfig(
        **asdict(base_config),
        access_token=get_secret("LAZADA_ACCESS_TOKEN", ""),
        refresh_token=get_secret("LAZADA_REFRESH_TOKEN", ""),
        app_key=get_secret("LAZADA_APP_KEY", ""),
        app_secret=get_secret("LAZADA_APP_SECRET", "")
    )


class LazadaClient(BasePlatformClient[LazadaClientConfig]):
    """
    Adapter for Lazada SDK. 
    Inherits retry/rate-limit logic but swaps transport for lazop.
    """

    def __init__(self, config: LazadaClientConfig, logger):
        super().__init__(config, logger)
        # Initialize the proprietary SDK client
        self.laz_client = LazopClient(
            "https://api.lazada.co.th/rest",  # Thailand region gateway
            self.config.app_key,
            self.config.app_secret
        )

    def _sign_request(self, method: str, path: str, params: Dict, body: Any) -> SignResult:
        """
        Lazada SDK handles its own signing, so we return 
        placeholder info or use this to prepare the LazopRequest.
        """
        # For Lazada, we don't need the Base class to call 'requests'
        # because the SDK does it. We can return dummy data or
        # use this hook to build the LazopRequest object.
        return SignResult(url=path, headers={}, params=params)

    def _perform_http_call(
        self,
        method: str,
        path: str,
        params: Dict[str, Any],
        body: Optional[Any]
    ) -> Dict[str, Any]:
        """
        OVERRIDE: Instead of using self.session (requests), 
        we use the Lazada SDK (lazop).
        """
        if self._check_timeout():
            raise TimeoutError("Execution exceeded config.timeout_seconds")

        self._wait_for_rate_limit()

        # 1. Build the SDK-specific request object
        request = LazopRequest(path, method)
        for key, value in params.items():
            # If value is list/dict, Lazada usually expects a JSON string
            val_str = json.dumps(value) if isinstance(
                value, (list, dict)) else str(value)
            request.add_api_param(key, val_str)

        # 2. Execute via SDK
        self.last_request_time = time.time()
        response = self.laz_client.execute(request, self.config.access_token)

        # 3. Handle SDK response format
        body_content = response.body
        if isinstance(body_content, str):
            body_content = json.loads(body_content)

        # 4. Standardized Error Checking (Lazada specific)
        if body_content.get('code') != '0':
            error_msg = body_content.get('message', 'Unknown error')
            # Trigger retry by raising exception
            raise Exception(f"Lazada API error: {error_msg}")

        return body_content
